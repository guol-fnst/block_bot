/* Block Bot – background service worker
 * Handles: LLM analysis (multi-provider), tab-scoped analysis jobs,
 * and persisted analysis cache so popup can be reopened without losing results.
 */
'use strict';

const BATCH_SIZE = 15;
const DEFAULT_CONFIDENCE_THRESHOLD = 0.8;
const ANALYSIS_KEY_PREFIX = 'analysisCache:';

const GEMINI_MODELS = [
  'gemini-3.1-flash-lite',
  'gemini-2.5-flash-lite',
  'gemini-2.5-flash',
  'gemini-1.5-flash'
];

const OPENAI_COMPAT_PRESETS = {
  deepseek: {
    url: 'https://api.deepseek.com/v1/chat/completions',
    defaultModel: 'deepseek-chat'
  },
  qwen: {
    url: 'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions',
    defaultModel: 'qwen-plus'
  }
};

const runningTabs = new Set();

const blockQueue = {
  queue: [],
  running: false,
  paused: false,
  total: 0,
  done: 0,
  failed: 0,
  consecutiveFails: 0,
  current: null,
  log: [],
  errorMsg: '',
  workerTabId: null
};

function geminiUrl(model) {
  return `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
}

function analysisKey(tabId) {
  return `${ANALYSIS_KEY_PREFIX}${tabId}`;
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

function withTimeout(promise, timeoutMs, timeoutMsg) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(timeoutMsg)), timeoutMs);
    promise
      .then(v => {
        clearTimeout(timer);
        resolve(v);
      })
      .catch(e => {
        clearTimeout(timer);
        reject(e);
      });
  });
}

function storageGet(keys) {
  return new Promise(resolve => chrome.storage.local.get(keys, resolve));
}

function storageSet(data) {
  return new Promise(resolve => chrome.storage.local.set(data, resolve));
}

function storageRemove(keys) {
  return new Promise(resolve => chrome.storage.local.remove(keys, resolve));
}

function tabsCreate(url, active = false) {
  return new Promise((resolve, reject) => {
    chrome.tabs.create({ url, active }, tab => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(tab);
      }
    });
  });
}

function tabsRemove(tabId) {
  return new Promise(resolve => chrome.tabs.remove(tabId, () => resolve()));
}

function tabsUpdate(tabId, updateProperties) {
  return new Promise((resolve, reject) => {
    chrome.tabs.update(tabId, updateProperties, tab => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(tab);
      }
    });
  });
}

function waitForTabLoaded(tabId, timeoutMs = 12000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(onUpdated);
      reject(new Error('后台屏蔽页面加载超时'));
    }, timeoutMs);

    function onUpdated(updatedTabId, info) {
      if (updatedTabId === tabId && info.status === 'complete') {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(onUpdated);
        resolve();
      }
    }

    chrome.tabs.onUpdated.addListener(onUpdated);
  });
}

async function ensureWorkerTab() {
  if (blockQueue.workerTabId) {
    try {
      await tabsUpdate(blockQueue.workerTabId, { active: false });
      return blockQueue.workerTabId;
    } catch (_) {
      blockQueue.workerTabId = null;
    }
  }

  const tab = await tabsCreate('https://x.com/home', false);
  blockQueue.workerTabId = tab.id;
  try {
    await waitForTabLoaded(tab.id, 18000);
  } catch (_) {
    // Continue even if timeout; next navigation may still work.
  }
  return tab.id;
}

async function cleanupWorkerTab() {
  if (!blockQueue.workerTabId) return;
  try {
    await tabsRemove(blockQueue.workerTabId);
  } catch (_) {}
  blockQueue.workerTabId = null;
}

function executeInTab(tabId, fn, args) {
  return new Promise((resolve, reject) => {
    chrome.scripting.executeScript(
      {
        target: { tabId },
        func: fn,
        args
      },
      results => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(results?.[0]?.result);
      }
    );
  });
}

async function blockViaHiddenTab(handle) {
  const handleSlug = String(handle || '').replace('@', '').trim();
  if (!handleSlug) {
    throw new Error('无效 handle，无法后台屏蔽');
  }

  const tabId = await ensureWorkerTab();
  const profileUrl = `https://x.com/${handleSlug}`;
  await tabsUpdate(tabId, { url: profileUrl, active: false });
  await waitForTabLoaded(tabId, 15000);

  const result = await executeInTab(
      tabId,
      async slug => {
        const sleep = ms => new Promise(r => setTimeout(r, ms));
        const waitFor = async (selector, timeout = 7000) => {
          const s = Date.now();
          while (Date.now() - s < timeout) {
            const el = document.querySelector(selector);
            if (el) return el;
            await sleep(140);
          }
          return null;
        };

        const moreBtn =
          (await waitFor('button[data-testid="userActions"]', 8000)) ||
          document.querySelector('button[aria-label*="More"]') ||
          document.querySelector('button[aria-label*="更多"]');

        if (!moreBtn) {
          return { ok: false, error: `后台页未找到用户操作按钮 @${slug}` };
        }

        moreBtn.click();
        await sleep(260);

        const blockItem =
          (await waitFor('[data-testid="block"]', 4500)) ||
          document.querySelector('[role="menuitem"][aria-label*="Block"]') ||
          document.querySelector('[role="menuitem"][aria-label*="屏蔽"]');

        if (!blockItem) {
          const maybeUnblock = document.querySelector('[data-testid="unblock"]');
          if (maybeUnblock) {
            return { ok: true, alreadyBlocked: true };
          }
          return { ok: false, error: `后台页未找到屏蔽菜单项 @${slug}` };
        }

        blockItem.click();

        const confirmBtn = await waitFor('[data-testid="confirmationSheetConfirm"]', 7000);
        if (!confirmBtn) {
          return { ok: false, error: `后台页未找到屏蔽确认按钮 @${slug}` };
        }

        confirmBtn.click();
        await sleep(800);
        return { ok: true };
      },
      [handleSlug]
    );

  if (!result?.ok) {
    throw new Error(result?.error || `后台屏蔽失败：${handle}`);
  }
  return { ok: true };
}

function getBlockStatusSnapshot() {
  return {
    queue: blockQueue.queue.map(q => ({ ...q })),
    running: blockQueue.running,
    paused: blockQueue.paused,
    total: blockQueue.total,
    done: blockQueue.done,
    failed: blockQueue.failed,
    consecutiveFails: blockQueue.consecutiveFails,
    current: blockQueue.current,
    log: blockQueue.log.slice(),
    errorMsg: blockQueue.errorMsg
  };
}

function recalcTotals() {
  blockQueue.total = blockQueue.queue.length;
  blockQueue.done = blockQueue.queue.filter(i => i.status === 'done').length;
  blockQueue.failed = blockQueue.queue.filter(i => i.status === 'failed').length;
}

function enqueueBlockAccounts(accounts) {
  const seen = new Set(blockQueue.queue.map(i => i.handle.toLowerCase()));
  let added = 0;

  (accounts || []).forEach(a => {
    const rawHandle = (a && a.handle ? a.handle : '').trim();
    if (!rawHandle) return;
    const handle = rawHandle.startsWith('@') ? rawHandle : `@${rawHandle}`;
    const key = handle.toLowerCase();
    if (seen.has(key)) return;
    seen.add(key);
    blockQueue.queue.push({
      handle,
      status: 'pending',
      attempts: 0,
      lastError: ''
    });
    added++;
  });

  recalcTotals();
  return added;
}

async function runGlobalBlockQueue() {
  const CONSECUTIVE_FAIL_LIMIT = 2;
  if (blockQueue.running) return;

  blockQueue.running = true;
  blockQueue.paused = false;
  blockQueue.errorMsg = '';

  try {
    while (true) {
      if (!blockQueue.running || blockQueue.paused) break;

      const item = blockQueue.queue.find(i => i.status === 'pending');
      if (!item) break;

      item.status = 'running';
      item.attempts += 1;
      blockQueue.current = item.handle;

      try {
        await blockViaHiddenTab(item.handle);
        item.status = 'done';
        blockQueue.consecutiveFails = 0;
        blockQueue.log.push({
          handle: item.handle,
          status: 'done',
          mode: 'background-ui',
          time: Date.now()
        });
      } catch (e) {
        item.status = 'failed';
        item.lastError = e.message || '失败';
        blockQueue.consecutiveFails += 1;
        blockQueue.log.push({
          handle: item.handle,
          status: 'failed',
          mode: 'background-ui',
          error: item.lastError,
          time: Date.now()
        });

        if (blockQueue.consecutiveFails >= CONSECUTIVE_FAIL_LIMIT) {
          blockQueue.paused = true;
          blockQueue.errorMsg = `连续 ${CONSECUTIVE_FAIL_LIMIT} 次失败，已自动暂停。`;
        }
      }

      recalcTotals();
      if (blockQueue.paused) break;

      const hasPending = blockQueue.queue.some(i => i.status === 'pending');
      if (hasPending) {
        // Faster randomized pace requested by user.
        await sleep(1000 + Math.random() * 2000);
      }
    }
  } finally {
    blockQueue.running = false;
    blockQueue.current = null;
    await cleanupWorkerTab();
  }
}

function buildPrompt(batch) {
  const tweetsJson = JSON.stringify(
    batch.map(t => ({
      handle: t.handle,
      displayName: t.displayName,
      text: t.text,
      hasUrl: /https?:\/\//.test(t.text),
      isReply: t.text.startsWith('@')
    })),
    null,
    2
  );

  return (
    '你是一个 Twitter/X 垃圾账号检测助手。请分析以下推文列表，判断每个账号是否疑似' +
    '垃圾账号、广告号或机器人号。\n\n' +
    '推文数据：\n' + tweetsJson + '\n\n' +
    '请对每个 handle 返回一个 JSON 数组，格式如下（只返回 JSON，不要加其他文字）：\n' +
    '[\n' +
    '  {\n' +
    '    "handle": "@xxx",\n' +
    '    "displayName": "...",\n' +
    '    "isSpamOrBot": true,\n' +
    '    "confidence": 0.91,\n' +
    '    "reason": "具体原因（中文）",\n' +
    '    "evidenceTweet": "命中的推文摘要"\n' +
    '  }\n' +
    ']\n\n' +
    '判断必须以推文内容与行为模式为主，不要仅因为账号名里有随机数字就判定为垃圾号。\n' +
    '高置信度特征：营销/广告/引流话术、重复模板语言、可疑短链接、' +
    '无实质内容的博眼球文字、机器人常见套路（抽奖转发等）、短时间内多条语义高度重复内容。\n' +
    '对于看起来正常的账号，isSpamOrBot 请返回 false，confidence 不要虚高。'
  );
}

function parseArrayFromModelText(rawText) {
  try {
    const parsed = JSON.parse(rawText);
    return Array.isArray(parsed) ? parsed : [];
  } catch (_) {
    const fenced = rawText.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (fenced) {
      try {
        const parsed = JSON.parse(fenced[1]);
        return Array.isArray(parsed) ? parsed : [];
      } catch (_) {}
    }
    const arrMatch = rawText.match(/\[[\s\S]*\]/);
    if (arrMatch) {
      try {
        const parsed = JSON.parse(arrMatch[0]);
        return Array.isArray(parsed) ? parsed : [];
      } catch (_) {}
    }
    return [];
  }
}

async function getProviderConfig() {
  const d = await storageGet([
    'llmProvider',
    'geminiApiKey',
    'geminiModel',
    'openaiApiKey',
    'openaiModel'
  ]);

  const rawProvider = d.llmProvider || 'gemini';
  const provider = rawProvider === 'deepseek' || rawProvider === 'qwen' || rawProvider === 'gemini'
    ? rawProvider
    : 'gemini';

  const preset = OPENAI_COMPAT_PRESETS[provider] || null;
  return {
    provider,
    geminiApiKey: d.geminiApiKey || '',
    geminiModel: d.geminiModel || 'auto',
    openaiApiKey: d.openaiApiKey || '',
    openaiApiUrl: preset ? preset.url : '',
    openaiModel: preset ? (d.openaiModel || preset.defaultModel) : ''
  };
}

function normalizeThreshold(raw) {
  const v = Number(raw);
  if (!Number.isFinite(v)) return DEFAULT_CONFIDENCE_THRESHOLD;
  if (v < 0.5) return 0.5;
  if (v > 1) return 1;
  return v;
}

async function getConfidenceThreshold() {
  const d = await storageGet(['spamConfidenceThreshold']);
  return normalizeThreshold(d.spamConfidenceThreshold);
}

async function analyzeBatchWithGemini(batch, cfg) {
  if (!cfg.geminiApiKey) {
    throw new Error('Gemini API Key 未设置。请在扩展设置页中配置后重试。');
  }

  const prompt = buildPrompt(batch);
  const body = {
    contents: [{ parts: [{ text: prompt }] }],
    generationConfig: {
      temperature: 0.1,
      responseMimeType: 'application/json'
    }
  };

  const modelList = cfg.geminiModel && cfg.geminiModel !== 'auto'
    ? [cfg.geminiModel, ...GEMINI_MODELS.filter(m => m !== cfg.geminiModel)]
    : GEMINI_MODELS;

  let lastError = null;
  for (let i = 0; i < modelList.length; i++) {
    const model = modelList[i];
    try {
      const resp = await fetch(`${geminiUrl(model)}?key=${encodeURIComponent(cfg.geminiApiKey)}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });

      if (!resp.ok) {
        const errText = await resp.text().catch(() => '');
        const err = new Error(`Gemini API 错误 (HTTP ${resp.status}): ${errText.slice(0, 200)}`);
        err.httpStatus = resp.status;
        throw err;
      }

      const data = await resp.json();
      const rawText = data?.candidates?.[0]?.content?.parts?.[0]?.text || '[]';
      return parseArrayFromModelText(rawText);
    } catch (e) {
      lastError = e;
      if (e.httpStatus === 404 && i < modelList.length - 1) {
        continue;
      }
      throw e;
    }
  }

  throw lastError || new Error('Gemini 分析失败：未找到可用模型');
}

async function analyzeBatchWithOpenAICompatible(batch, cfg) {
  if (!cfg.openaiApiUrl) {
    throw new Error('OpenAI 兼容 API URL 未设置。');
  }
  if (!cfg.openaiApiKey) {
    throw new Error('OpenAI 兼容 API Key 未设置。');
  }
  if (!cfg.openaiModel) {
    throw new Error('OpenAI 兼容模型名未设置。');
  }

  const prompt = buildPrompt(batch);
  const body = {
    model: cfg.openaiModel,
    messages: [
      { role: 'system', content: '你是一个严格输出 JSON 的分类助手。' },
      { role: 'user', content: prompt }
    ],
    temperature: 0.1
  };

  const resp = await fetch(cfg.openaiApiUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${cfg.openaiApiKey}`
    },
    body: JSON.stringify(body)
  });

  if (!resp.ok) {
    const errText = await resp.text().catch(() => '');
    throw new Error(`OpenAI 兼容 API 错误 (HTTP ${resp.status}): ${errText.slice(0, 200)}`);
  }

  const data = await resp.json();
  const rawText = data?.choices?.[0]?.message?.content || '[]';
  return parseArrayFromModelText(rawText);
}

async function analyzeBatch(batch, cfg) {
  if (cfg.provider === 'gemini') {
    return analyzeBatchWithGemini(batch, cfg);
  }
  if (cfg.provider === 'deepseek' || cfg.provider === 'qwen') {
    return analyzeBatchWithOpenAICompatible(batch, cfg);
  }
  throw new Error('不支持的模型服务提供商');
}

function shouldFallbackToChunk(error) {
  const msg = String(error?.message || '').toLowerCase();
  return msg.includes('context') || msg.includes('token') || msg.includes('too large') || msg.includes('413');
}

async function analyzeTweetsOptimized(tweets, cfg, onProgress) {
  if (!tweets || tweets.length === 0) return [];

  // Prefer one-shot full analysis to reduce per-request overhead/token boilerplate.
  try {
    const all = await analyzeBatch(tweets, cfg);
    if (onProgress) {
      await onProgress(tweets.length, tweets.length);
    }
    return all;
  } catch (e) {
    if (!shouldFallbackToChunk(e)) {
      throw e;
    }
  }

  // Fallback only when context/token size is too large.
  const results = [];
  for (let i = 0; i < tweets.length; i += BATCH_SIZE) {
    const batch = tweets.slice(i, i + BATCH_SIZE);
    const batchResults = await analyzeBatch(batch, cfg);
    results.push(...batchResults);

    if (onProgress) {
      const done = Math.min(i + BATCH_SIZE, tweets.length);
      await onProgress(done, tweets.length);
    }

    if (i + BATCH_SIZE < tweets.length) {
      await sleep(700);
    }
  }
  return results;
}

function normalizeCandidates(results, confidenceThreshold = DEFAULT_CONFIDENCE_THRESHOLD) {
  const filtered = results.filter(
    r => r.isSpamOrBot && Number(r.confidence || 0) >= confidenceThreshold
  );
  const byHandle = {};

  filtered.forEach(r => {
    if (!r || !r.handle) return;
    const key = String(r.handle).toLowerCase();
    if (!byHandle[key] || Number(r.confidence || 0) > Number(byHandle[key].confidence || 0)) {
      byHandle[key] = {
        handle: r.handle,
        displayName: r.displayName || '',
        confidence: Number(r.confidence || 0),
        reason: r.reason || '',
        evidenceTweet: r.evidenceTweet || '',
        selected: true
      };
    }
  });

  return Object.values(byHandle).sort((a, b) => b.confidence - a.confidence);
}

function sendToTab(tabId, msg) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, msg, resp => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(resp);
      }
    });
  });
}

function ensureContentScript(tabId) {
  return new Promise((resolve, reject) => {
    chrome.scripting.executeScript(
      { target: { tabId }, files: ['content/content.js'] },
      () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve();
        }
      }
    );
  });
}

async function sendToTabSafe(tabId, msg) {
  try {
    return await sendToTab(tabId, msg);
  } catch (e) {
    const missingReceiver = String(e.message || '').includes('Receiving end does not exist');
    if (!missingReceiver) throw e;
    await ensureContentScript(tabId);
    return sendToTab(tabId, msg);
  }
}

async function setAnalysisState(tabId, state) {
  const key = analysisKey(tabId);
  await storageSet({
    [key]: {
      ...state,
      tabId,
      updatedAt: Date.now()
    }
  });
}

async function getAnalysisState(tabId) {
  const key = analysisKey(tabId);
  const data = await storageGet([key]);
  return data[key] || null;
}

async function startAnalysisForTab(tabId) {
  if (runningTabs.has(tabId)) return;
  runningTabs.add(tabId);

  try {
    await setAnalysisState(tabId, {
      status: 'running',
      scannedTweetCount: 0,
      candidates: [],
      error: '',
      progressText: '正在采集推文…'
    });

    const scrapeResp = await withTimeout(
      sendToTabSafe(tabId, { action: 'scrapeTweets' }),
      15000,
      '采集超时，请刷新页面后重试'
    );
    if (!scrapeResp?.ok) {
      throw new Error(scrapeResp?.error || '采集失败');
    }

    const tweets = scrapeResp.tweets || [];
    if (tweets.length === 0) {
      await setAnalysisState(tabId, {
        status: 'empty',
        scannedTweetCount: 0,
        candidates: [],
        error: '',
        progressText: ''
      });
      return;
    }

    await setAnalysisState(tabId, {
      status: 'running',
      scannedTweetCount: tweets.length,
      candidates: [],
      error: '',
      progressText: `正在分析 ${tweets.length} 条推文…`
    });

    const cfg = await getProviderConfig();
    const results = await analyzeTweetsOptimized(tweets, cfg, async (done, total) => {
      await setAnalysisState(tabId, {
        status: 'running',
        scannedTweetCount: total,
        candidates: [],
        error: '',
        progressText: `正在分析：${done}/${total}`
      });
    });

    const confidenceThreshold = await getConfidenceThreshold();
    const candidates = normalizeCandidates(results, confidenceThreshold);
    await setAnalysisState(tabId, {
      status: candidates.length > 0 ? 'done' : 'empty',
      scannedTweetCount: tweets.length,
      candidates,
      error: '',
      progressText: ''
    });
  } catch (e) {
    const prev = (await getAnalysisState(tabId)) || { scannedTweetCount: 0 };
    await setAnalysisState(tabId, {
      status: 'error',
      scannedTweetCount: prev.scannedTweetCount || 0,
      candidates: [],
      error: e.message || '分析失败',
      progressText: ''
    });
  } finally {
    runningTabs.delete(tabId);
  }
}

// ── Message handler ───────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.action === 'backgroundUiBlock') {
    blockViaHiddenTab(msg.handle)
      .then(() => sendResponse({ ok: true }))
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }

  if (msg.action === 'enqueueGlobalBlockAccounts') {
    const added = enqueueBlockAccounts(msg.accounts || []);
    runGlobalBlockQueue();
    sendResponse({ ok: true, added, status: getBlockStatusSnapshot() });
    return false;
  }

  if (msg.action === 'getGlobalBlockStatus') {
    sendResponse({ ok: true, status: getBlockStatusSnapshot() });
    return false;
  }

  if (msg.action === 'pauseGlobalBlocking') {
    blockQueue.paused = true;
    blockQueue.running = false;
    blockQueue.current = null;
    sendResponse({ ok: true, status: getBlockStatusSnapshot() });
    return false;
  }

  if (msg.action === 'resumeGlobalBlocking') {
    blockQueue.paused = false;
    blockQueue.errorMsg = '';
    runGlobalBlockQueue();
    sendResponse({ ok: true, status: getBlockStatusSnapshot() });
    return false;
  }

  if (msg.action === 'startAnalysisForTab') {
    startAnalysisForTab(msg.tabId);
    sendResponse({ ok: true });
    return false;
  }

  if (msg.action === 'getAnalysisForTab') {
    getAnalysisState(msg.tabId)
      .then(state => sendResponse({ ok: true, state }))
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }

  if (msg.action === 'clearAnalysisForTab') {
    storageRemove([analysisKey(msg.tabId)])
      .then(() => sendResponse({ ok: true }))
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }

});
