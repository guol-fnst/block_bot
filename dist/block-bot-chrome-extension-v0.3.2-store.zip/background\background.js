/* Block Bot – background service worker
 * Handles: LLM analysis (multi-provider), tab-scoped analysis jobs,
 * and persisted analysis cache so popup can be reopened without losing results.
 */
'use strict';

const DEFAULT_ANALYSIS_BATCH_SIZE = 25;
const DEFAULT_ANALYSIS_PARALLELISM = 0; // 0 = provider-based auto
const DEFAULT_SCRAPE_SCROLL_WAIT_MS = 1200;
const DEFAULT_SCRAPE_MAX_ROUNDS = 120;
const DEFAULT_SCRAPE_MAX_TWEETS = 1000;
const DEFAULT_SCRAPE_STAGNANT_ROUNDS = 4;
const CONFIDENCE_THRESHOLD = 0.8;
const MAX_TWEET_TEXT_LENGTH = 220;
const MAX_TEXTS_PER_HANDLE_FOR_AI = 5;
const ANALYSIS_KEY_PREFIX = 'analysisCache:';
const API_RETRY_MAX_ATTEMPTS = 4;
const API_RETRY_BASE_DELAY_MS = 800;
const API_RETRY_MAX_DELAY_MS = 8000;
const API_FETCH_TIMEOUT_MS = 30000;

const PERSIST_BLOCK_QUEUE_KEY = 'blockQueueState';
const PERSIST_TASK_SESSIONS_KEY = 'taskSessions';
const MAX_TASK_SESSIONS = 20;
const MAX_CONCURRENT_ANALYSES = 2;
const PERSIST_DEEP_SCAN_KEY  = 'deepScanPersist';
const CIRCUIT_BREAKER_THRESHOLD = 5;

const GEMINI_MODELS = [
  'gemini-3.1-flash-lite',
  'gemini-2.5-pro',
  'gemini-2.5-flash-lite',
  'gemini-2.5-flash',
  'gemini-2.0-flash',
  'gemini-2.0-flash-lite',
  'gemini-1.5-flash'
];

const runningTabs = new Set();

// 当前页面分析缓存：tabId => { scannedUserHandles: Set, currentUrl: string }
// 用于避免重复分析同一用户
const pageAnalysisCache = {};

const blockQueue = {
  queue: [],
  running: false,
  paused: false,
  total: 0,
  done: 0,
  failed: 0,
  consecutiveFails: 0,
  current: null,
  log: [],
  errorMsg: '',
  workerTabId: null
};

// Task-level session history (each enqueue call = one session)
const taskSessions = [];

// Deep Scan State
const deepScanState = {
  running: false,
  paused: false,
  cancelled: false,
  handle: '',
  config: {},
  postsCount: 0,
  repliesCount: 0,
  repliesCollected: [],
  candidates: [],
  candidatesCount: 0,
  completed: false,
  currentStep: '待启动',
  scannedPostUrls: new Set(),
  workerTabId: null,
  error: ''
};

function geminiUrl(model) {
  return `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
}

function analysisKey(tabId) {
  return `${ANALYSIS_KEY_PREFIX}${tabId}`;
}

// ─── 页面分析缓存管理 ────────────────────────────────────────────────────────

/**
 * 初始化或更新 tab 缓存
 * 如果 URL 变化，清空该 tab 的缓存
 */
function initPageAnalysisCache(tabId, url) {
  if (!pageAnalysisCache[tabId]) {
    pageAnalysisCache[tabId] = {
      scannedUserHandles: new Set(),
      currentUrl: url
    };
  } else if (pageAnalysisCache[tabId].currentUrl !== url) {
    // URL 变化，清空缓存
    console.log(`[Cache] Tab ${tabId} URL 变化，清空缓存: ${pageAnalysisCache[tabId].currentUrl} → ${url}`);
    pageAnalysisCache[tabId] = {
      scannedUserHandles: new Set(),
      currentUrl: url
    };
  }
}

/**
 * 添加已扫描的用户 handle
 */
function addScannedUserHandles(tabId, handles) {
  if (!pageAnalysisCache[tabId]) return;
  const before = pageAnalysisCache[tabId].scannedUserHandles.size;
  (handles || []).forEach(handle => {
    const key = String(handle || '').replace('@', '').toLowerCase();
    pageAnalysisCache[tabId].scannedUserHandles.add(key);
  });
  const after = pageAnalysisCache[tabId].scannedUserHandles.size;
  if (after > before) {
    console.log(`[Cache] Tab ${tabId} 已扫描用户数: ${before} → ${after}`);
  }
}

/**
 * 过滤出新用户（未扫描过的）
 * 返回需要分析的新用户
 */
function filterNewUsers(tabId, users) {
  if (!pageAnalysisCache[tabId]) {
    return users;
  }
  const cached = pageAnalysisCache[tabId].scannedUserHandles;
  const newUsers = (users || []).filter(u => {
    const key = String(u.handle || '').replace('@', '').toLowerCase();
    return !cached.has(key);
  });
  
  const skipped = (users || []).length - newUsers.length;
  if (skipped > 0) {
    console.log(`[Cache] Tab ${tabId} 跳过 ${skipped} 个已扫描用户，分析 ${newUsers.length} 个新用户`);
  }
  return newUsers;
}

/**
 * 清空指定 tab 的缓存
 */
function clearPageAnalysisCache(tabId) {
  if (pageAnalysisCache[tabId]) {
    console.log(`[Cache] 清空 Tab ${tabId} 的缓存`);
    delete pageAnalysisCache[tabId];
  }
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

function withTimeout(promise, timeoutMs, timeoutMsg) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(timeoutMsg)), timeoutMs);
    promise
      .then(v => {
        clearTimeout(timer);
        resolve(v);
      })
      .catch(e => {
        clearTimeout(timer);
        reject(e);
      });
  });
}

function isRetryableHttpStatus(status) {
  return status === 408 || status === 429 || (status >= 500 && status <= 599);
}

function shouldTryNextGeminiModel(error) {
  const status = Number(error?.httpStatus || 0);
  return status === 429 || (status >= 500 && status <= 599);
}

function parseRetryAfterMs(value) {
  if (!value) return null;
  const seconds = Number(value);
  if (Number.isFinite(seconds)) {
    return Math.max(0, seconds * 1000);
  }

  const dateMs = Date.parse(value);
  if (!Number.isNaN(dateMs)) {
    return Math.max(0, dateMs - Date.now());
  }

  return null;
}

function retryDelayMs(attemptIndex, retryAfterValue) {
  const retryAfterMs = parseRetryAfterMs(retryAfterValue);
  if (retryAfterMs !== null) {
    return Math.min(retryAfterMs, API_RETRY_MAX_DELAY_MS);
  }

  const exponential = API_RETRY_BASE_DELAY_MS * (2 ** Math.max(0, attemptIndex - 1));
  const jitter = Math.floor(Math.random() * 250);
  return Math.min(exponential + jitter, API_RETRY_MAX_DELAY_MS);
}

async function fetchWithRetry(url, options, label) {
  let lastError = null;

  for (let attempt = 1; attempt <= API_RETRY_MAX_ATTEMPTS; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), API_FETCH_TIMEOUT_MS);

    try {
      const resp = await fetch(url, {
        ...options,
        signal: controller.signal
      });
      clearTimeout(timer);

      if (resp.ok || !isRetryableHttpStatus(resp.status)) {
        return resp;
      }

      const errText = await resp.text().catch(() => '');
      const err = new Error(`${label} 错误 (HTTP ${resp.status}): ${errText.slice(0, 200)}`);
      err.httpStatus = resp.status;
      lastError = err;

      if (attempt < API_RETRY_MAX_ATTEMPTS) {
        await sleep(retryDelayMs(attempt, resp.headers?.get('retry-after')));
        continue;
      }

      throw err;
    } catch (e) {
      clearTimeout(timer);
      lastError = e;
      if (e.httpStatus || attempt >= API_RETRY_MAX_ATTEMPTS) {
        throw e;
      }
      await sleep(retryDelayMs(attempt));
    }
  }

  throw lastError || new Error(`${label} 请求失败`);
}

function storageGet(keys) {
  return new Promise(resolve => chrome.storage.local.get(keys, resolve));
}

function storageSet(data) {
  return new Promise(resolve => chrome.storage.local.set(data, resolve));
}

function storageRemove(keys) {
  return new Promise(resolve => chrome.storage.local.remove(keys, resolve));
}

// ─── 状态持久化（防止 Service Worker 重启丢数据）─────────────────────────────

/**
 * 将屏蔽队列关键字段写入 storage。
 * 在 recalcTotals / pause / resume 等关键节点触发（fire-and-forget）。
 */
function saveBlockQueueState() {
  // Trim log to last 50 entries before persisting.
  if (blockQueue.log.length > 50) {
    blockQueue.log.splice(0, blockQueue.log.length - 50);
  }
  storageSet({
    [PERSIST_BLOCK_QUEUE_KEY]: {
      queue:    blockQueue.queue.map(i => ({ ...i })),
      log:      blockQueue.log.slice(),
      paused:   blockQueue.paused,
      errorMsg: blockQueue.errorMsg
    }
  }).catch(e => console.warn('[Persist] saveBlockQueueState failed:', e));
}

function saveTaskSessions() {
  storageSet({ [PERSIST_TASK_SESSIONS_KEY]: taskSessions.slice() })
    .catch(e => console.warn('[Persist] saveTaskSessions failed:', e));
}

/**
 * 将 Deep Scan 关键字段写入 storage。
 * 在扫描完成、出错、步骤里程碑时触发（fire-and-forget）。
 */
function saveDeepScanState() {
  storageSet({
    [PERSIST_DEEP_SCAN_KEY]: {
      running:         deepScanState.running,
      handle:          deepScanState.handle,
      config:          deepScanState.config,
      postsCount:      deepScanState.postsCount,
      repliesCount:    deepScanState.repliesCount,
      candidatesCount: deepScanState.candidatesCount,
      completed:       deepScanState.completed,
      currentStep:     deepScanState.currentStep,
      error:           deepScanState.error,
      // Only persist candidates when the scan has finished; avoid bloat mid-run.
      candidates:      deepScanState.completed ? deepScanState.candidates : []
    }
  }).catch(e => console.warn('[Persist] saveDeepScanState failed:', e));
}

/**
 * Service Worker 启动时从 storage 恢复上次状态。
 * blockQueue 中处于 'running' 的条目（上次被中断）回退为 'pending'。
 * deepScanState 如果上次正在运行则标记为中断错误；若已完成则保留结果。
 */
async function restorePersistedState() {
  const data = await storageGet([PERSIST_BLOCK_QUEUE_KEY, PERSIST_DEEP_SCAN_KEY, PERSIST_TASK_SESSIONS_KEY]);

  const bq = data[PERSIST_BLOCK_QUEUE_KEY];
  if (bq) {
    blockQueue.queue = (bq.queue || []).map(i => ({
      ...i,
      // Items that were mid-block when the SW died must be retried.
      status: i.status === 'running' ? 'pending' : i.status
    }));
    blockQueue.log     = bq.log     || [];
    blockQueue.paused  = bq.paused  || false;
    blockQueue.errorMsg= bq.errorMsg|| '';
    recalcTotals();
    console.log(`[Persist] Restored blockQueue: ${blockQueue.queue.length} items`);
  }

  const ts = data[PERSIST_TASK_SESSIONS_KEY];
  if (Array.isArray(ts)) {
    taskSessions.splice(0, taskSessions.length, ...ts);
  }

  const ds = data[PERSIST_DEEP_SCAN_KEY];
  if (ds) {
    deepScanState.handle          = ds.handle          || '';
    deepScanState.config          = ds.config          || {};
    deepScanState.postsCount      = ds.postsCount      || 0;
    deepScanState.repliesCount    = ds.repliesCount    || 0;
    deepScanState.candidatesCount = ds.candidatesCount || 0;
    deepScanState.completed       = ds.completed       || false;
    deepScanState.candidates      = ds.candidates      || [];

    if (ds.running && !ds.completed) {
      // SW was killed while scan was in progress – cannot resume, show error.
      deepScanState.running     = false;
      deepScanState.error       = 'Service Worker 已重启，扫描中断。请重新发起深度扫描。';
      deepScanState.currentStep = '扫描已中断（后台进程重启）';
    } else {
      deepScanState.error       = ds.error       || '';
      deepScanState.currentStep = ds.currentStep || '';
    }
    console.log(`[Persist] Restored deepScanState: handle=${deepScanState.handle} completed=${deepScanState.completed} error=${deepScanState.error}`);
  }
}

// Restore persisted state as soon as the service worker starts.
// By the time the first message arrives (requires a popup round-trip),
// this IIFE will have already completed.
(async () => {
  try { await restorePersistedState(); } catch (e) { console.error('[Persist] Restore failed:', e); }
})();

function tabsCreate(url, active = false) {
  return new Promise((resolve, reject) => {
    chrome.tabs.create({ url, active }, tab => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(tab);
      }
    });
  });
}

function tabsRemove(tabId) {
  return new Promise(resolve => chrome.tabs.remove(tabId, () => resolve()));
}

function tabsUpdate(tabId, updateProperties) {
  return new Promise((resolve, reject) => {
    chrome.tabs.update(tabId, updateProperties, tab => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(tab);
      }
    });
  });
}

function waitForTabLoaded(tabId, timeoutMs = 12000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(onUpdated);
      reject(new Error('后台屏蔽页面加载超时'));
    }, timeoutMs);

    function onUpdated(updatedTabId, info) {
      if (updatedTabId === tabId && info.status === 'complete') {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(onUpdated);
        resolve();
      }
    }

    chrome.tabs.onUpdated.addListener(onUpdated);
  });
}

async function ensureWorkerTab() {
  if (blockQueue.workerTabId) {
    try {
      // #11 fix: confirm tab is fully loaded before reuse to avoid navigation race
      const existingTab = await chrome.tabs.get(blockQueue.workerTabId);
      if (existingTab.status !== 'complete') {
        await waitForTabLoaded(blockQueue.workerTabId, 10000).catch(() => {});
      }
      return blockQueue.workerTabId;
    } catch (_) {
      blockQueue.workerTabId = null;
    }
  }

  const tab = await tabsCreate('https://x.com/home', false);
  blockQueue.workerTabId = tab.id;
  try {
    await waitForTabLoaded(tab.id, 18000);
  } catch (_) {
    // Continue even if timeout; next navigation may still work.
  }
  return tab.id;
}

async function cleanupWorkerTab() {
  if (!blockQueue.workerTabId) return;
  try {
    await tabsRemove(blockQueue.workerTabId);
  } catch (_) {}
  blockQueue.workerTabId = null;
}

function executeInTab(tabId, fn, args) {
  return new Promise((resolve, reject) => {
    chrome.scripting.executeScript(
      {
        target: { tabId },
        func: fn,
        args
      },
      results => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(results?.[0]?.result);
      }
    );
  });
}

async function blockViaHiddenTab(handle) {
  const handleSlug = String(handle || '').replace('@', '').trim();
  if (!handleSlug) {
    throw new Error('无效 handle，无法后台屏蔽');
  }

  const tabId = await ensureWorkerTab();
  const profileUrl = `https://x.com/${handleSlug}`;
  await tabsUpdate(tabId, { url: profileUrl, active: false });
  await waitForTabLoaded(tabId, 15000);

  const result = await executeInTab(
      tabId,
      async slug => {
        const sleep = ms => new Promise(r => setTimeout(r, ms));
        const waitFor = async (selector, timeout = 7000) => {
          const s = Date.now();
          while (Date.now() - s < timeout) {
            const el = document.querySelector(selector);
            if (el) return el;
            await sleep(140);
          }
          return null;
        };

        const moreBtn =
          (await waitFor('button[data-testid="userActions"]', 8000)) ||
          document.querySelector('button[aria-label*="More"]') ||
          document.querySelector('button[aria-label*="更多"]') ||
          // #12 fix: multilingual fallback via aria-haspopup
          document.querySelector('[data-testid="User-Name"]')
            ?.closest('[data-testid="UserCell"], article, [data-testid="primaryColumn"]')
            ?.querySelector('button[aria-haspopup="menu"]');

        if (!moreBtn) {
          return { ok: false, error: `后台页未找到用户操作按钮 @${slug}` };
        }

        moreBtn.click();
        await sleep(260);

        const blockItem =
          (await waitFor('[data-testid="block"]', 4500)) ||
          document.querySelector('[role="menuitem"][aria-label*="Block"]') ||
          document.querySelector('[role="menuitem"][aria-label*="屏蔽"]') ||
          // #12 fix: text-based fallback for other UI languages
          // Use word-boundary so "Unblock" / "Entblockieren" etc. are NOT matched.
          Array.from(document.querySelectorAll('[role="menuitem"]')).find(el => /\bblock\b/i.test(el.textContent || ''));

        if (!blockItem) {
          const maybeUnblock = document.querySelector('[data-testid="unblock"]');
          if (maybeUnblock) {
            return { ok: true, alreadyBlocked: true };
          }
          return { ok: false, error: `后台页未找到屏蔽菜单项 @${slug}` };
        }

        blockItem.click();

        const confirmBtn = await waitFor('[data-testid="confirmationSheetConfirm"]', 7000);
        if (!confirmBtn) {
          return { ok: false, error: `后台页未找到屏蔽确认按钮 @${slug}` };
        }

        confirmBtn.click();
        await sleep(800);
        return { ok: true };
      },
      [handleSlug]
    );

  if (!result?.ok) {
    throw new Error(result?.error || `后台屏蔽失败：${handle}`);
  }
  return { ok: true };
}

function getBlockStatusSnapshot() {
  return {
    queue: blockQueue.queue.map(q => ({ ...q })),
    running: blockQueue.running,
    paused: blockQueue.paused,
    total: blockQueue.total,
    done: blockQueue.done,
    failed: blockQueue.failed,
    consecutiveFails: blockQueue.consecutiveFails,
    current: blockQueue.current,
    log: blockQueue.log.slice(),
    errorMsg: blockQueue.errorMsg,
    recentSessions: taskSessions.slice(-3).slice().reverse(),
    allSessions: taskSessions.slice().reverse()
  };
}

function recalcTotals() {
  blockQueue.total  = blockQueue.queue.length;
  blockQueue.done   = blockQueue.queue.filter(i => i.status === 'done').length;
  blockQueue.failed = blockQueue.queue.filter(i => i.status === 'failed').length;
  // Persist after every status change so SW restarts lose at most one item.
  saveBlockQueueState();
}

function retryFailedBlockItems() {
  let count = 0;
  blockQueue.queue.forEach(item => {
    if (item.status === 'failed') {
      item.status = 'pending';
      item.lastError = '';
      count++;
    }
  });
  blockQueue.consecutiveFails = 0;
  blockQueue.errorMsg = '';
  recalcTotals();
  return count;
}

function clearCompletedBlockItems() {
  const before = blockQueue.queue.length;
  blockQueue.queue = blockQueue.queue.filter(i => i.status !== 'done');
  blockQueue.log = blockQueue.log.filter(i => i.status !== 'done');
  recalcTotals();
  return before - blockQueue.queue.length;
}

function enqueueBlockAccounts(accounts, meta = {}) {
  const seen = new Set(blockQueue.queue.map(i => i.handle.toLowerCase()));
  let added = 0;
  const sessionId = Date.now();

  (accounts || []).forEach(a => {
    const rawHandle = (a && a.handle ? a.handle : '').trim();
    if (!rawHandle) return;
    const handle = rawHandle.startsWith('@') ? rawHandle : `@${rawHandle}`;
    const key = handle.toLowerCase();
    if (seen.has(key)) return;
    seen.add(key);
    blockQueue.queue.push({
      handle,
      status: 'pending',
      attempts: 0,
      lastError: '',
      sessionId
    });
    added++;
  });

  if (added > 0) {
    const session = {
      id: sessionId,
      timestamp: sessionId,
      sourceUrl: String(meta.sourceUrl || ''),
      scannedCount: Number(meta.scannedCount) || 0,
      candidateCount: Number(meta.candidateCount) || 0,
      enqueuedCount: added,
      done: 0,
      failed: 0
    };
    taskSessions.push(session);
    if (taskSessions.length > MAX_TASK_SESSIONS) {
      taskSessions.splice(0, taskSessions.length - MAX_TASK_SESSIONS);
    }
    saveTaskSessions();
  }

  recalcTotals();
  return added;
}

async function runGlobalBlockQueue() {
  if (blockQueue.running) return;

  blockQueue.running = true;
  blockQueue.paused = false;
  blockQueue.errorMsg = '';

  try {
    while (true) {
      if (!blockQueue.running || blockQueue.paused) break;

      const item = blockQueue.queue.find(i => i.status === 'pending');
      if (!item) break;

      item.status = 'running';
      item.attempts += 1;
      blockQueue.current = item.handle;

      try {
        await blockViaHiddenTab(item.handle);
        item.status = 'done';
        blockQueue.consecutiveFails = 0;
        blockQueue.log.push({
          handle: item.handle,
          status: 'done',
          mode: 'background-ui',
          time: Date.now()
        });
        if (item.sessionId) {
          const sess = taskSessions.find(s => s.id === item.sessionId);
          if (sess) { sess.done++; saveTaskSessions(); }
        }
      } catch (e) {
        item.status = 'failed';
        item.lastError = e.message || '失败';
        blockQueue.consecutiveFails += 1;
        blockQueue.log.push({
          handle: item.handle,
          status: 'failed',
          mode: 'background-ui',
          error: item.lastError,
          time: Date.now()
        });
        if (item.sessionId) {
          const sess = taskSessions.find(s => s.id === item.sessionId);
          if (sess) { sess.failed++; saveTaskSessions(); }
        }

        // Issue #10: close dirty tab on failure so next attempt gets fresh tab.
        await cleanupWorkerTab();

        // Circuit breaker: auto-pause after N consecutive failures so a dead
        // X session doesn’t silently spin through the entire queue.
        if (blockQueue.consecutiveFails >= CIRCUIT_BREAKER_THRESHOLD) {
          blockQueue.paused   = true;
          blockQueue.errorMsg = `连续失败 ${blockQueue.consecutiveFails} 次，已自动暂停。请检查 X 登录状态后点击「继续」重试。`;
          recalcTotals();
          break;
        }
      }

      recalcTotals();

      const hasPending = blockQueue.queue.some(i => i.status === 'pending');
      if (hasPending) {
        // Faster randomized pace requested by user.
        await sleep(1000 + Math.random() * 2000);
      }
    }
  } finally {
    blockQueue.running = false;
    blockQueue.current = null;
    if (!blockQueue.paused) {
      await cleanupWorkerTab();
    }
  }
}

function parseHandlesFromText(text) {
  const parts = String(text || '')
    .split(/[\s,，;；\n\t]+/)
    .map(s => s.trim())
    .filter(Boolean);

  const handles = [];
  for (const p of parts) {
    const m = p.match(/^@?[A-Za-z0-9_]{1,30}$/);
    if (!m) continue;
    handles.push({ handle: p.startsWith('@') ? p : `@${p}` });
  }
  return handles;
}

function defaultDetectionRules() {
  return (
    '【高置信度特征】：\n' +
    '1. 营销/广告/引流话术、重复模板语言、可疑短链接\n' +
    '2. 无实质内容的博眼球文字、机器人常见套路（抽奖转发等）\n' +
    '3. 短时间内多条语义高度重复内容\n' +
    '4. ⭐【自动回复机器人】：推文结构高度模板化，包含大量重复短语、固定话术块、\n' +
    '   相同的账号/话题提及（如 @xxx、#xxx 出现频次异常高），\n' +
    '   仅在特定位置有变化（如开头感叹词：卧槽、牛逼、炸裂 等，\n' +
    '   但中间核心内容完全相同），这是自动回复/复制粘贴机器人的典型表现。\n' +
    '   请提高这类推文的可疑程度。\n' +
    '5. 推文中如果存在重复出现的长短语或整段复制的结构，高度怀疑是模板自动发送。'
  );
}

function enhancedDefaultDetectionRules() {
  return (
    defaultDetectionRules() + '\n' +
    '6. 【同串灌水机器人】：只有当同一条帖子下，多个不同账号在短时间内出现明显近重复、模板化、\n' +
    '   批量复述、空泛接话且几乎没有新增信息时，才提高可疑度。\n' +
    '   必须优先看是否存在：复制粘贴、同模板改写、异常一致的句式、装饰模板、引流/广告/黄赌骗信号，\n' +
    '   或与随机 handle、异常显示名、低熵文本等其他风险信号叠加。\n' +
    '   如果只是围绕社会议题、新闻、职场、养老、代际矛盾等话题发表正常短观点、反驳、举例、情绪化表达，\n' +
    '   即使多个账号立场相近、语气接近、handle 含数字，也默认按真人讨论处理，不要仅凭“同主题短回复”判为机器人。'
  );
}

function buildPrompt(batch, customDetectionPrompt = '') {
  // #7 fix: group tweets by handle so the LLM sees all messages per user
  // and can detect copy-paste / template-bot patterns more reliably.
  const grouped = new Map();
  (batch || []).forEach(t => {
    const key = String(t.handle || '').toLowerCase();
    if (!grouped.has(key)) {
      grouped.set(key, { handle: t.handle, displayName: t.displayName, texts: [] });
    }
    const entry = grouped.get(key);
    if (t.text && entry.texts.length < MAX_TEXTS_PER_HANDLE_FOR_AI) {
      const full = String(t.text).replace(/\s+/g, ' ').trim();
      entry.texts.push(full.length > MAX_TWEET_TEXT_LENGTH ? full.slice(0, MAX_TWEET_TEXT_LENGTH) + '…' : full);
    }
  });

  const tweetsJson = JSON.stringify(
    Array.from(grouped.values()).map(t => ({
      h: t.handle,
      n: t.displayName,
      t: t.texts,
      c: t.texts.length,
      u: t.texts.some(text => /https?:\/\//.test(text)),
      r: t.texts.some(text => text.startsWith('@')),
      d: new Set(t.texts.join('')).size
    }))
  );

  const rules = String(customDetectionPrompt || '').trim() || enhancedDefaultDetectionRules();

  return (
    '你是 Twitter/X 垃圾账号检测器。目标是找出高置信垃圾号、广告号、诈骗号、引流号或机器人号。\n' +
    '输入字段：h=handle，n=显示名，t=最多3条推文/回复文本，c=文本数，u=含URL，r=像回复，d=字符多样性。\n' +
    '账号数据(JSON)：' + tweetsJson + '\n\n' +
    '只返回疑似账号；正常账号或证据不足账号不要返回。只输出 JSON 数组，不要加解释文字。\n' +
    '数组元素格式：\n' +
    '[\n' +
    '  {\n' +
    '    "handle": "@xxx",\n' +
    '    "displayName": "...",\n' +
    '    "isSpamOrBot": true,\n' +
    '    "confidence": 0.91,\n' +
    '    "reason": "具体原因（中文）",\n' +
    '    "evidenceTweet": "命中的推文摘要"\n' +
    '  }\n' +
    ']\n\n' +
    '判断必须以推文内容、重复模式、诱导行为和上下文风险为主；随机数字或陌生用户名只能作为辅助信号，不能单独定性。\n' +
    '如果多账号文本高度模板化/复制粘贴，或单账号多条文本明显自动化，可提高置信度。\n' +
    '如果只是普通观点、短赞同、新闻更新、产品账号、含数字用户名但内容正常，请不要返回。\n\n' +
    rules + '\n\n' +
    'confidence 使用 0.80-1.00；低于 0.80 或证据不足不要返回。'
  );
}

function parseArrayFromModelText(rawText) {
  try {
    const parsed = JSON.parse(rawText);
    return Array.isArray(parsed) ? parsed : [];
  } catch (_) {
    const fenced = rawText.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (fenced) {
      try {
        const parsed = JSON.parse(fenced[1]);
        return Array.isArray(parsed) ? parsed : [];
      } catch (_) {}
    }
    const arrMatch = rawText.match(/\[[\s\S]*\]/);
    if (arrMatch) {
      try {
        const parsed = JSON.parse(arrMatch[0]);
        return Array.isArray(parsed) ? parsed : [];
      } catch (_) {}
    }
    return [];
  }
}

function normalizeThreshold(raw) {
  const v = Number(raw);
  if (!Number.isFinite(v)) return CONFIDENCE_THRESHOLD;
  if (v < 0.5) return 0.5;
  if (v > 1) return 1;
  return v;
}

function normalizeInt(raw, min, max, fallback) {
  const v = Number(raw);
  if (!Number.isFinite(v)) return fallback;
  const n = Math.round(v);
  if (n < min) return min;
  if (n > max) return max;
  return n;
}

function normalizeAnalysisBatchSize(raw) {
  return normalizeInt(raw, 5, 40, DEFAULT_ANALYSIS_BATCH_SIZE);
}

function normalizeAnalysisParallelism(raw) {
  const v = Number(raw);
  if (!Number.isFinite(v)) return DEFAULT_ANALYSIS_PARALLELISM;
  if (v <= 0) return 0;
  return normalizeInt(v, 1, 6, 0);
}

function normalizeScrapeScrollWaitMs(raw) {
  return normalizeInt(raw, 600, 2500, DEFAULT_SCRAPE_SCROLL_WAIT_MS);
}

function normalizeScrapeMaxRounds(raw) {
  return normalizeInt(raw, 6, 300, DEFAULT_SCRAPE_MAX_ROUNDS);
}

function normalizeScrapeMaxTweets(raw) {
  return normalizeInt(raw, 20, 5000, DEFAULT_SCRAPE_MAX_TWEETS);
}

function normalizeScrapeStagnantRounds(raw) {
  return normalizeInt(raw, 2, 8, DEFAULT_SCRAPE_STAGNANT_ROUNDS);
}

function normalizeOpenAICompatibleApiUrl(rawUrl) {
  const trimmed = String(rawUrl || '').trim();
  if (!trimmed) return '';

  try {
    const url = new URL(trimmed);
    const path = url.pathname.replace(/\/+$/, '');
    if (path === '' || path === '/v1') {
      url.pathname = `${path || '/v1'}/chat/completions`;
      return url.toString();
    }
  } catch (_) {
    return trimmed;
  }

  return trimmed;
}

async function getProviderConfig() {
  const d = await storageGet([
    'llmProvider',
    'geminiApiKey',
    'geminiModel',
    'openaiApiKey',
    'openaiApiUrl',
    'openaiModel',
    'openaiApiType',
    'spamConfidenceThreshold',
    'obviousBotKeywords',
    'customDetectionPrompt',
    'aiAnalysisEnabled',
    'analysisBatchSize',
    'analysisParallelism',
    'scrapeScrollWaitMs',
    'scrapeMaxRounds',
    'scrapeMaxTweets',
    'scrapeStagnantRounds'
  ]);

  const provider = d.llmProvider || 'gemini';
  return {
    provider,
    geminiApiKey: d.geminiApiKey || '',
    geminiModel: d.geminiModel || 'auto',
    openaiApiKey: d.openaiApiKey || '',
    openaiApiUrl: normalizeOpenAICompatibleApiUrl(d.openaiApiUrl),
    openaiModel: d.openaiModel || '',
    openaiApiType: d.openaiApiType || (provider === 'anthropic' ? 'anthropic' : 'openai_compat'),
    spamConfidenceThreshold: normalizeThreshold(d.spamConfidenceThreshold),
    obviousBotKeywords: normalizeKeywordList(d.obviousBotKeywords),
    customDetectionPrompt: d.customDetectionPrompt || '',
    aiAnalysisEnabled: Boolean(d.aiAnalysisEnabled),
    analysisBatchSize: normalizeAnalysisBatchSize(d.analysisBatchSize),
    analysisParallelism: normalizeAnalysisParallelism(d.analysisParallelism),
    scrapeScrollWaitMs: normalizeScrapeScrollWaitMs(d.scrapeScrollWaitMs),
    scrapeMaxRounds: normalizeScrapeMaxRounds(d.scrapeMaxRounds),
    scrapeMaxTweets: normalizeScrapeMaxTweets(d.scrapeMaxTweets),
    scrapeStagnantRounds: normalizeScrapeStagnantRounds(d.scrapeStagnantRounds)
  };
}

function getProviderConfigIssue(cfg) {
  if (cfg.provider === 'gemini') {
    return cfg.geminiApiKey ? '' : 'Gemini API Key 未设置。请先打开设置页配置模型服务。';
  }

  if (!cfg.openaiApiUrl) return 'API URL 未设置。请先打开设置页配置模型服务。';
  if (!cfg.openaiModel) return '模型名未设置。请先打开设置页配置模型服务。';
  if (!cfg.openaiApiKey) return 'API Key 未设置。请先打开设置页配置模型服务。';
  return '';
}

function canUseAiProvider(cfg) {
  return Boolean(cfg?.aiAnalysisEnabled) && !getProviderConfigIssue(cfg);
}

async function testProviderConfig() {
  const cfg = await getProviderConfig();
  const issue = getProviderConfigIssue(cfg);
  if (issue) throw new Error(issue);

  const sample = [{
    handle: '@block_bot_test',
    displayName: 'Block Bot Test',
    text: 'This is a normal configuration test message.',
    tweetUrl: '',
    profileUrl: 'https://x.com/block_bot_test'
  }];

  await analyzeBatch(sample, cfg);
  return {
    provider: cfg.provider,
    model: cfg.provider === 'gemini' ? cfg.geminiModel : cfg.openaiModel
  };
}

async function analyzeBatchWithGemini(batch, cfg) {
  if (!cfg.geminiApiKey) {
    throw new Error('Gemini API Key 未设置。请在扩展设置页中配置后重试。');
  }

  const prompt = buildPrompt(batch, cfg.customDetectionPrompt);
  const body = {
    contents: [{ parts: [{ text: prompt }] }],
    generationConfig: {
      temperature: 0.1,
      responseMimeType: 'application/json'
    }
  };

  const modelList = cfg.geminiModel && cfg.geminiModel !== 'auto'
    ? [cfg.geminiModel, ...GEMINI_MODELS.filter(m => m !== cfg.geminiModel)]
    : GEMINI_MODELS;

  let lastError = null;
  for (let i = 0; i < modelList.length; i++) {
    const model = modelList[i];
    try {
      const resp = await fetchWithRetry(
        `${geminiUrl(model)}?key=${encodeURIComponent(cfg.geminiApiKey)}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body)
        },
        `Gemini API (${model})`
      );

      if (!resp.ok) {
        const errText = await resp.text().catch(() => '');
        const err = new Error(`Gemini API 错误 (HTTP ${resp.status}): ${errText.slice(0, 200)}`);
        err.httpStatus = resp.status;
        throw err;
      }

      const data = await resp.json();
      const rawText = data?.candidates?.[0]?.content?.parts?.[0]?.text || '[]';
      return parseArrayFromModelText(rawText);
    } catch (e) {
      lastError = e;
      if (e.httpStatus === 404 && i < modelList.length - 1) {
        continue;
      }
      if (shouldTryNextGeminiModel(e) && i < modelList.length - 1) {
        continue;
      }
      throw e;
    }
  }

  throw lastError || new Error('Gemini 分析失败：未找到可用模型');
}

async function analyzeBatchWithOpenAICompatible(batch, cfg) {
  if (!cfg.openaiApiUrl) {
    throw new Error('OpenAI 兼容 API URL 未设置。');
  }
  if (!cfg.openaiApiKey) {
    throw new Error('OpenAI 兼容 API Key 未设置。');
  }
  if (!cfg.openaiModel) {
    throw new Error('OpenAI 兼容模型名未设置。');
  }

  const prompt = buildPrompt(batch, cfg.customDetectionPrompt);
  const body = {
    model: cfg.openaiModel,
    messages: [
      { role: 'system', content: '你是一个严格输出 JSON 的分类助手。' },
      { role: 'user', content: prompt }
    ],
    temperature: 0.1
  };

  const resp = await fetchWithRetry(
    cfg.openaiApiUrl,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${cfg.openaiApiKey}`
      },
      body: JSON.stringify(body)
    },
    'OpenAI 兼容 API'
  );

  if (!resp.ok) {
    const errText = await resp.text().catch(() => '');
    throw new Error(`OpenAI 兼容 API 错误 (HTTP ${resp.status}): ${errText.slice(0, 200)}`);
  }

  const data = await resp.json();
  const rawText = data?.choices?.[0]?.message?.content || '[]';
  return parseArrayFromModelText(rawText);
}

async function analyzeBatchWithAnthropic(batch, cfg) {
  if (!cfg.openaiApiUrl) {
    throw new Error('Anthropic API URL 未设置。');
  }
  if (!cfg.openaiApiKey) {
    throw new Error('Anthropic API Key 未设置。');
  }
  if (!cfg.openaiModel) {
    throw new Error('Anthropic 模型名未设置。');
  }

  const prompt = buildPrompt(batch, cfg.customDetectionPrompt);
  const body = {
    model: cfg.openaiModel,
    max_tokens: 4096,
    temperature: 0.1,
    system: '你是一个严格输出 JSON 的分类助手。',
    messages: [
      { role: 'user', content: prompt }
    ]
  };

  const resp = await fetchWithRetry(
    cfg.openaiApiUrl,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': cfg.openaiApiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify(body)
    },
    'Anthropic API'
  );

  if (!resp.ok) {
    const errText = await resp.text().catch(() => '');
    throw new Error(`Anthropic API 错误 (HTTP ${resp.status}): ${errText.slice(0, 200)}`);
  }

  const data = await resp.json();
  const textParts = Array.isArray(data?.content)
    ? data.content.filter(p => p?.type === 'text').map(p => p.text || '')
    : [];
  return parseArrayFromModelText(textParts.join('\n') || '[]');
}

async function analyzeBatch(batch, cfg) {
  if (cfg.provider === 'gemini') {
    return analyzeBatchWithGemini(batch, cfg);
  }
  if (cfg.provider === 'anthropic' || cfg.openaiApiType === 'anthropic') {
    return analyzeBatchWithAnthropic(batch, cfg);
  }
  return analyzeBatchWithOpenAICompatible(batch, cfg);
}

function shouldFallbackToChunk(error) {
  const msg = String(error?.message || '').toLowerCase();
  return msg.includes('context') || msg.includes('token') || msg.includes('too large') || msg.includes('413');
}

function getParallelBatchConcurrency(cfg) {
  const configured = Number(cfg?.analysisParallelism || 0);
  if (configured > 0) {
    return Math.min(6, Math.max(1, Math.round(configured)));
  }

  const provider = String(cfg?.provider || '').toLowerCase();
  const apiType = String(cfg?.openaiApiType || '').toLowerCase();

  // Keep concurrency conservative to reduce provider rate-limit spikes.
  if (provider === 'gemini') return 2;
  if (provider === 'anthropic' || apiType === 'anthropic') return 2;
  return 3;
}

function preClusterSimilarTweets(tweets) {
  if (!tweets || tweets.length <= 1) {
    return { representatives: tweets, clusterMap: {} };
  }

  const clusterMap = {}; // repHandle_lower → [memberTweets]
  const clustered = new Set();
  const representatives = [];

  for (let i = 0; i < tweets.length; i++) {
    const ti = tweets[i];
    const keyI = (ti.handle || '').toLowerCase();
    if (clustered.has(keyI)) continue;

    representatives.push(ti);
    clustered.add(keyI);
    const textI = ti.text || (ti.texts && ti.texts[0]) || '';

    for (let j = i + 1; j < tweets.length; j++) {
      const tj = tweets[j];
      const keyJ = (tj.handle || '').toLowerCase();
      if (clustered.has(keyJ)) continue;

      const textJ = tj.text || (tj.texts && tj.texts[0]) || '';
      if (calcTextSimilarity(textI, textJ) > 0.85) {
        if (!clusterMap[keyI]) clusterMap[keyI] = [];
        clusterMap[keyI].push(tj);
        clustered.add(keyJ);
      }
    }
  }

  const clusterCount = Object.values(clusterMap).reduce((s, a) => s + a.length, 0);
  if (clusterCount > 0) {
    console.log(`[PreCluster] 预聚类缩减: ${tweets.length} → ${representatives.length} (${clusterCount} 聚类成员)`);
  }
  return { representatives, clusterMap };
}

function expandClusterResults(aiResults, clusterMap) {
  if (!clusterMap || Object.keys(clusterMap).length === 0) return aiResults || [];

  const expanded = [...(aiResults || [])];
  (aiResults || []).forEach(r => {
    const key = (r.handle || '').toLowerCase();
    const members = clusterMap[key];
    if (members) {
      members.forEach(m => {
        expanded.push({
          ...r,
          handle: m.handle,
          displayName: m.displayName || r.displayName,
          reason: (r.reason || '') + ' | 复制粘贴聚类成员',
          evidenceTweet: m.text || r.evidenceTweet || ''
        });
      });
    }
  });

  console.log(`[PreCluster] 结果展开: ${(aiResults || []).length} → ${expanded.length}`);
  return expanded;
}

async function analyzeTweetsOptimized(tweets, cfg, onProgress) {
  if (!tweets || tweets.length === 0) return [];

  // 预聚类：相似度 >85% 的推文只发一条代表到 AI
  const { representatives, clusterMap } = preClusterSimilarTweets(tweets);

  const batchSize = normalizeAnalysisBatchSize(cfg?.analysisBatchSize);

  if (representatives.length <= batchSize) {
    const all = await analyzeBatch(representatives, cfg);
    if (onProgress) {
      await onProgress(representatives.length, representatives.length);
    }
    return expandClusterResults(all, clusterMap);
  }

  const batches = [];
  for (let i = 0; i < representatives.length; i += batchSize) {
    batches.push(representatives.slice(i, i + batchSize));
  }

  const total = representatives.length;
  const parallel = Math.max(1, Math.min(getParallelBatchConcurrency(cfg), batches.length));
  const resultsByBatch = new Array(batches.length);
  let nextBatchIndex = 0;
  let doneCount = 0;

  const worker = async workerId => {
    if (workerId > 0) {
      await sleep(workerId * 120);
    }

    while (true) {
      const batchIndex = nextBatchIndex;
      nextBatchIndex += 1;
      if (batchIndex >= batches.length) return;

      const batch = batches[batchIndex];
      const batchResults = await analyzeBatch(batch, cfg);
      resultsByBatch[batchIndex] = batchResults;
      doneCount += batch.length;

      if (onProgress) {
        await onProgress(Math.min(doneCount, total), total);
      }
    }
  };

  await Promise.all(Array.from({ length: parallel }, (_, i) => worker(i)));
  return expandClusterResults(resultsByBatch.flat(), clusterMap);
}

function compactText(text) {
  return String(text || '').replace(/\s+/g, '').trim();
}

function stripEmojiLikeChars(text) {
  return String(text || '')
    .replace(/[\p{Extended_Pictographic}\uFE0F]/gu, '')
    .replace(/[^\p{L}\p{N}]/gu, '')
    .trim();
}

const BUILT_IN_OBVIOUS_BOT_KEYWORDS = [
  '同城',
  '附近',
  '资源',
  '主页',
  '主页自取',
  '真实资源',
  '约炮',
  '约萢',
  '速配',
  '线下',
  '无偿',
  '免费',
  '破处',
  '男大',
  '搭子',
  '弟弟',
  '哥哥',
  '主人',
  '找主人',
  '温柔主人',
  '今夜有空',
  '想约',
  '想月',
  '寂寞',
  '陪聊',
  '交友',
  '嫂',
  'sao货',
  '能打',
  '炮友',
  '找炮',
  '固炮',
  '上门',
  '外围',
  '裸聊',
  '私房',
  '包夜',
  '空降',
  '兼职',
  '援交',
  '楼凤',
  'onlyfans',
  'escort',
  'hookup',
  'porn',
  'nude',
  '\u597d\u6da9',
  '\u7b2c\u4e00\u9a9a',
  'casino',
  '夸克网盘',
  '夸克盘',
  'pan.quark.cn',
  'quark网盘'
];

const LOCAL_RULE_SPAM_TEXT_PATTERNS = [
  /\b(airdrop|mint|claim|giveaway|whitelist|presale|casino|bonus|jackpot)\b/i,
  /\b(onlyfans|escort|hookup|dating|adult|nude|porn)\b/i,
  /\b(dm me|message me|link in bio|check my profile|join telegram|join discord)\b/i,
  /\b(telegram|whatsapp|discord\.gg|t\.me\/|wa\.me\/|bit\.ly|tinyurl)\b/i,
  /空投|白名单|领币|钱包|合约|私信|引流|返佣|博彩|投注|百家乐|真人荷官|电报群|飞机群|看主页|主页见|主页自取|真实资源|资源自取|链接在简介/,
  /同城|附近|约炮|速配|上门|外围|裸聊|私房|包夜/,
  /今夜有空|今晚有空|想约|想月|找个.{0,4}主人|温柔主人|寂寞|陪聊|交友/
];

const ADULT_LURE_SHORTCOPY_PATTERNS = [
  /\u7ebf\u4e0b\u6211\u5c31[\u66f0\u65e5]\u8fc7/u,
  /\u5979\u597d\u6da9.*\u6211\u4e0d\u884c\u4e86/u,
  /\u5237\u4e86\u534a\u5929\u7684x.*\u4e3b\u9875\u80fd\u6253/u,
  /\u6bd4\u5979\u597d\u770b\u7684\u6ca1\u5979\u9a9a.*\u6bd4\u5979\u9a9a\u7684\u6ca1\u5979\u597d\u770b/u,
  /\u771f\u5b9e\u8d44\u6e90.*\u4e3b\u9875\u81ea\u53d6/u,
  /\u8fd9\u4e2a\u9a9a\u8d27/u,
  /\u4e3b\u9875\u80fd\u6253/u
];

function hasCloudDrivePromoSignal(text, customKeywords = []) {
  const value = String(text || '').toLowerCase();
  if (!value) return false;

  const compact = value.replace(/\s+/g, '');
  if (
    compact.includes('pan.quark.cn') ||
    compact.includes('quark.cn/s/') ||
    compact.includes('夸克网盘') ||
    compact.includes('夸克盘') ||
    compact.includes('quark网盘')
  ) {
    return true;
  }

  return normalizeKeywordList(customKeywords).some(keyword => {
    const k = String(keyword || '').toLowerCase().trim();
    return k && value.includes(k);
  });
}

function normalizeKeywordList(keywords) {
  const raw = Array.isArray(keywords)
    ? keywords
    : String(keywords || '').split(/[\n,，、;；]+/);
  const seen = new Set();
  return raw
    .map(k => String(k || '').trim())
    .filter(Boolean)
    .filter(k => {
      const key = k.toLowerCase();
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .slice(0, 100);
}

function hasObviousBotKeyword(text, customKeywords = []) {
  const value = String(text || '').toLowerCase();
  if (!value) return false;
  return BUILT_IN_OBVIOUS_BOT_KEYWORDS
    .concat(normalizeKeywordList(customKeywords))
    .some(keyword => value.includes(keyword.toLowerCase()));
}

function looksLikeRandomHandle(handle) {
  const slug = String(handle || '').replace(/^@/, '');
  return (
    /^[A-Z][a-z]+[A-Z][a-z]+\d{3,}$/.test(slug) ||
    /^[A-Za-z]{5,}\d{3,}$/.test(slug) ||
    /^[a-z0-9]{10,}$/.test(slug) && /\d{3,}/.test(slug) && /[a-z]/.test(slug)
  );
}

function isTinyTokenReply(text) {
  const s = compactText(text);
  if (!s) return true;
  return (
    /^[a-z]?\d{1,4}$/i.test(s) ||
    /^[a-z]\d{1,3}[a-z]?$/i.test(s) ||
    /^[\^~._-]?\d{1,4}$/.test(s)
  );
}

function isEmojiOnlyOrEmojiNumberReply(text) {
  const s = compactText(text);
  if (!s) return false;
  if (!/[\p{Extended_Pictographic}\uFE0F]/u.test(s)) return false;
  return stripEmojiLikeChars(s).replace(/\d+/g, '') === '';
}

function isLowInfoMixedEmojiReply(text) {
  const s = compactText(text);
  if (!s) return false;
  if (!/[\p{Extended_Pictographic}\uFE0F]/u.test(s)) return false;

  const core = stripEmojiLikeChars(s);
  if (!core || !/^[a-z0-9]+$/i.test(core)) return false;

  const digitCount = (core.match(/\d/g) || []).length;
  const alphaCount = (core.match(/[a-z]/gi) || []).length;

  // Typical bot fragments like: "43mB", "85nW", "2uT" after removing emojis.
  return core.length >= 2 && core.length <= 6 && digitCount >= 1 && alphaCount <= 2;
}

function isSingleLetterEmojiLureReply(text) {
  const raw = String(text || '').trim();
  if (!raw) return false;
  if (countEmojiChars(raw) < 2) return false;

  const core = stripEmojiLikeChars(raw);
  return /^[a-z]$/i.test(core);
}

function hasSuspiciousPromoText(text) {
  const value = String(text || '');
  return LOCAL_RULE_SPAM_TEXT_PATTERNS.some(pattern => pattern.test(value));
}

function hasAdultLureShortCopy(text) {
  const value = String(text || '');
  if (!value) return false;

  const compact = compactText(value).toLowerCase();
  if (!compact || compact.length > 32) return false;

  return ADULT_LURE_SHORTCOPY_PATTERNS.some(pattern => pattern.test(value));
}

function hasUrlLikeSignal(text) {
  return /(https?:\/\/|www\.|t\.co\/|bit\.ly\/|tinyurl\.com\/|t\.me\/|wa\.me\/|discord\.gg\/|line\.me\/)/i.test(String(text || ''));
}

function hasLowTextEntropy(text) {
  const compact = compactText(text).toLowerCase();
  if (compact.length < 8) return false;
  const chars = new Set(compact.split(''));
  const diversity = chars.size / compact.length;
  const digitCount = (compact.match(/\d/g) || []).length;
  return diversity < 0.32 || digitCount >= Math.max(5, compact.length * 0.55);
}

function hasDecorativeTemplateSignal(text) {
  const raw = String(text || '').trim();
  const compact = compactText(raw);
  if (compact.length < 18) return false;

  const emojiCount = (raw.match(/[\p{Extended_Pictographic}\uFE0F]/gu) || []).length;
  const symbolCount = (raw.match(/[^\p{L}\p{N}\s.,!?'"，。！？、:;（）()@#]/gu) || []).length;
  const latinWordCount = (raw.match(/[a-z]{3,}/gi) || []).length;
  const cjkCount = (raw.match(/[\u4e00-\u9fff\u3400-\u4dbf\uf900-\ufaff]/g) || []).length;
  const lineCount = raw.split(/\n+/).map(s => s.trim()).filter(Boolean).length;
  const symbolRatio = symbolCount / compact.length;

  return (
    (emojiCount >= 3 && symbolCount >= 6 && latinWordCount >= 3) ||
    (lineCount >= 2 && symbolCount >= 4 && symbolRatio >= 0.12 && (latinWordCount >= 3 || cjkCount >= 4)) ||
    (symbolCount >= 10 && symbolRatio >= 0.2 && latinWordCount >= 3)
  );
}

function countEmojiChars(text) {
  return (String(text || '').match(/[\p{Extended_Pictographic}\uFE0F]/gu) || []).length;
}

function hasEmojiBurst(text, minCount = 5) {
  return countEmojiChars(text) >= minCount;
}

/**
 * Returns true when the text begins with 2+ consecutive Unicode mathematical /
 * set-theory / misc-technical operator characters (U+2200–U+23FF, U+2700–U+27BF,
 * U+2A00–U+2AFF) or a slash-based decorative prefix like "// ⚡ /\".
 * This is a hallmark of a newer spam-bot wave that uses math symbols as visual
 * decoration before a short generic English sentence (e.g. @mnxabrv38895,
 * @Pzthc162184, @dmegjsui22230, @zogsa71014, @vaoefxb2234).
 */
function hasMathSymbolPrefix(text) {
  const t = String(text || '').trimStart();
  // 2+ consecutive chars from Mathematical Operators / Misc Technical /
  // Supplemental Mathematical Operators / Misc Symbols & Arrows blocks
  if (/^[\u2200-\u23FF\u2700-\u27BF\u2A00-\u2AFF]{2}/u.test(t)) return true;
  // Slash-based decorative prefix: "//" or "/\" at the very start
  if (/^\/[\/\\]/.test(t)) return true;
  return false;
}

/**
 * Returns true when the text contains 4+ characters from obscure Unicode script blocks
 * (U+A000–U+ABFF: Yi, Lisu, Vai, Bamum Supplement, Kayah Li, Rejang, Javanese, Myanmar
 * Extended-B, Cham, Myanmar Extended-A, Tai Viet, Meetei Mayek, etc.) combined with a
 * short generic English phrase and at least one emoji.
 *
 * Spam bots use these scripts as visual "wrapper" decoration around a 4-14 word English
 * inspirational/generic sentence, e.g.:
 *   ⧒ꩄꩅꩆꚨꩩꩩ Keep exploring the beautiful big world outside ꩪꩫꩬꩅꩆꩇ⧓ 💦🎉💼
 *   〝ꨬꨭꨮꩨꩩ Every child writes their own beautiful life story ꩪꩫꩬꨭꨮꨯ〞 🌐🔥
 *   ⧕꩙꩚꩛ꩶ꩷꩷ Grow stronger little by little each day ꚨꩩꩪ꩚꩛꩜⧖ 🎌🌱
 */
function hasObscureScriptDecoration(text) {
  const raw = String(text || '').trim();
  if (!raw) return false;

  const obscureMatches = raw.match(/[\uA000-\uABFF]/gu) || [];
  if (obscureMatches.length < 4) return false;

  const words = raw.match(/[a-zA-Z]{2,}/g) || [];
  if (words.length < 4 || words.length > 14) return false;

  const firstWord = raw.match(/[a-zA-Z]{2,}/);
  if (!firstWord) return false;

  const allWords = Array.from(raw.matchAll(/[a-zA-Z]{2,}/g));
  const lastWord = allWords[allWords.length - 1];
  const firstWordIndex = firstWord.index || 0;
  const lastWordEnd = (lastWord.index || 0) + lastWord[0].length;

  const prefix = raw.slice(0, firstWordIndex);
  const suffix = raw.slice(lastWordEnd);
  const prefixObscure = (prefix.match(/[\uA000-\uABFF]/gu) || []).length;
  const suffixObscure = (suffix.match(/[\uA000-\uABFF]/gu) || []).length;
  if (prefixObscure < 2 || suffixObscure < 2) return false;

  const englishLen = words.join('').length;
  const totalLen = raw.replace(/\s/g, '').length;
  if (totalLen === 0 || englishLen / totalLen > 0.86) return false;

  return true;
}

function hasDecoratedCjkBotPattern(text) {
  const raw = String(text || '').trim();
  if (!raw) return false;

  const cjkMatches = raw.match(/[\u4e00-\u9fff\u3400-\u4dbf\uf900-\ufaff]/gu) || [];
  if (cjkMatches.length < 5 || cjkMatches.length > 16) return false;

  const firstCjk = raw.match(/[\u4e00-\u9fff\u3400-\u4dbf\uf900-\ufaff]/u);
  const allCjk = Array.from(raw.matchAll(/[\u4e00-\u9fff\u3400-\u4dbf\uf900-\ufaff]/gu));
  const lastCjk = allCjk[allCjk.length - 1];
  if (!firstCjk || !lastCjk) return false;

  const firstCjkIndex = firstCjk.index || 0;
  const lastCjkEnd = (lastCjk.index || 0) + lastCjk[0].length;
  const prefix = raw.slice(0, firstCjkIndex);
  const suffix = raw.slice(lastCjkEnd);

  // Count decorative wrappers broadly, including replacement chars that X occasionally
  // emits when uncommon glyphs fail to round-trip through innerText.
  const decorativeMatches = s => s.match(/[\uFFFD\u1d00-\u1d7f\u2070-\u209f\u2100-\u214f\u2190-\u2bff\u3000-\u303f\ua000-\uabff\p{Extended_Pictographic}]/gu) || [];
  const superscriptLikeMatches = s => s.match(/[\u1d2c-\u1d7f\u2070-\u209f]/gu) || [];
  const prefixDecorative = decorativeMatches(prefix).length;
  const suffixDecorative = decorativeMatches(suffix).length;
  const superscriptPrefix = superscriptLikeMatches(prefix).length;
  const asciiWordCount = (raw.match(/[a-zA-Z]{2,}/g) || []).length;

  if (asciiWordCount > 2) return false;

  return (
    (prefixDecorative >= 2 && suffixDecorative >= 2) ||
    (superscriptPrefix >= 4 && suffixDecorative >= 1)
  );
}

/**
 * Returns true when the text is a short English phrase (4–13 words)
 * sandwiched inside heavy emoji/symbol decoration — the hallmark of
 * inspirational-quote bot accounts like @ansqyfgo458, @Hralx284483 etc.
 */
function hasEmojiDecoratedShortEnglishPhrase(text) {
  const raw = String(text || '').trim();
  if (!raw) return false;

  // Need at least 5 emoji chars for "heavy decoration"
  if (countEmojiChars(raw) < 5) return false;

  // Pull out English words (2+ letters)
  const words = raw.match(/[a-zA-Z]{2,}/g) || [];
  if (words.length < 4 || words.length > 13) return false;

  // English characters must NOT dominate — decoration must be substantial.
  // Threshold 0.75: even an 8-word phrase like "I fall in love with you more every morning"
  // has a ratio of ~0.62 (heavy emoji framing keeps total chars high), so 0.75 is the right ceiling.
  const englishLen = words.join('').length;
  const totalLen = raw.replace(/\s/g, '').length;
  if (totalLen > 0 && englishLen / totalLen > 0.75) return false;

  return true;
}

function getEnglishJokeTemplateFamily(text) {
  const raw = String(text || '').trim();
  if (!raw) return '';

  const compact = stripEmojiLikeChars(raw)
    .replace(/[“”‘’]/g, "'")
    .replace(/[—–]/g, '-')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();

  if (!compact || compact.length < 24) return '';

  if (/^why did [^?]{2,90}\?\s+.{6,220}$/.test(compact)) return 'why-did';
  if (/^i tried to .{4,140}[.!?]\s*i .{4,180}$/.test(compact)) return 'i-tried-to';
  if (/^what do you call .{2,120}\?\s+.{4,200}$/.test(compact)) return 'what-do-you-call';
  if (/^my .{2,80} said .{2,140}[.!?]\s+.{4,180}$/.test(compact)) return 'my-said';

  return '';
}

function buildLocalRuleHit(tweet, confidence, reasons) {
  return {
    handle: String(tweet?.handle || ''),
    displayName: String(tweet?.displayName || ''),
    isSpamOrBot: true,
    confidence,
    reason: `Local rules: ${reasons.join(', ')}`,
    evidenceTweet: String(tweet?.text || '').trim(),
    source: 'local-rules',
    selected: confidence >= 0.9
  };
}

function detectObviousBotReply(tweet, customKeywords = []) {
  const text = String(tweet?.text || '').trim();
  const displayName = String(tweet?.displayName || '');
  const handle = String(tweet?.handle || '');
  const reasons = [];

  const adultName = hasObviousBotKeyword(displayName, customKeywords) || hasObviousBotKeyword(handle, customKeywords);
  const cloudDrivePromo = hasCloudDrivePromoSignal(text, customKeywords);
  const randomHandle = looksLikeRandomHandle(handle);
  const tinyToken = isTinyTokenReply(text);
  const emojiOnly = isEmojiOnlyOrEmojiNumberReply(text);
  const lowInfoMixed = isLowInfoMixedEmojiReply(text);
  const singleLetterEmojiLure = isSingleLetterEmojiLureReply(text);
  const suspiciousPromoText = hasSuspiciousPromoText(text);
  const adultLureShortCopy = hasAdultLureShortCopy(text);
  const urlLike = hasUrlLikeSignal(text);
  const lowEntropy = hasLowTextEntropy(handle) || hasLowTextEntropy(displayName);
  const lowInfoText = stripEmojiLikeChars(text).length <= 8;
  const defaultAvatar = Boolean(tweet?.defaultProfileImage);
  const decorativeTemplate = hasDecorativeTemplateSignal(text);
  const jokeTemplateFamily = getEnglishJokeTemplateFamily(text);
  const emojiBurst = hasEmojiBurst(text, 5);
  const emojiDecoratedPhrase = hasEmojiDecoratedShortEnglishPhrase(text);
  const mathPrefix = hasMathSymbolPrefix(text);
  const obscureScriptDeco = hasObscureScriptDecoration(text);
  const decoratedCjkPattern = hasDecoratedCjkBotPattern(text);

  if (adultName) reasons.push('display name or handle contains adult/spam lure keywords');
  if (cloudDrivePromo) reasons.push('reply text contains cloud-drive promo link keywords');
  if (randomHandle) reasons.push('handle looks randomly generated');
  if (tinyToken) reasons.push('reply text is only a tiny token/number');
  if (emojiOnly) reasons.push('reply text is only emoji or emoji plus numbers');
  if (lowInfoMixed) reasons.push('reply text is emoji mixed with very short alnum fragments');
  if (singleLetterEmojiLure) reasons.push('reply text is a single letter wrapped by emoji decoration');
  if (suspiciousPromoText) reasons.push('reply text contains spam/scam promo wording');
  if (adultLureShortCopy) reasons.push('reply text matches short adult-lure bot copy');
  if (urlLike) reasons.push('reply text contains external link or off-platform contact');
  if (lowEntropy) reasons.push('profile text has low-entropy/generated-looking pattern');
  if (defaultAvatar) reasons.push('account appears to use a default profile image');
  if (decorativeTemplate) reasons.push('reply text looks like a decorative template bot message');
  if (jokeTemplateFamily) reasons.push(`reply text matches repetitive english joke template (${jokeTemplateFamily})`);
  if (emojiBurst) reasons.push('reply text has unusually dense emoji decoration');
  if (emojiDecoratedPhrase) reasons.push('reply text is a short english phrase wrapped in emoji decoration');
  if (mathPrefix) reasons.push('text starts with math/unicode-operator symbol prefix (bot decoration pattern)');
  if (obscureScriptDeco) reasons.push('text wraps English phrase in obscure Unicode script characters (bot decoration)');
  if (decoratedCjkPattern) reasons.push('text wraps a short CJK phrase in decorative symbols/superscript glyphs (bot decoration)');

  if (cloudDrivePromo) {
    return buildLocalRuleHit(tweet, 0.96, reasons);
  }

  if ((adultName && (tinyToken || emojiOnly || randomHandle || lowInfoMixed || singleLetterEmojiLure)) || (randomHandle && (tinyToken || emojiOnly || lowInfoMixed || singleLetterEmojiLure))) {
    return buildLocalRuleHit(tweet, 0.98, reasons);
  }

  if (suspiciousPromoText && (urlLike || adultName || randomHandle || lowEntropy)) {
    return buildLocalRuleHit(tweet, urlLike ? 0.94 : 0.9, reasons);
  }

  if (adultLureShortCopy) {
    return buildLocalRuleHit(tweet, 0.93, reasons);
  }

  if (suspiciousPromoText && lowInfoText) {
    return buildLocalRuleHit(tweet, 0.9, reasons);
  }

  if (randomHandle && jokeTemplateFamily && emojiBurst) {
    return buildLocalRuleHit(tweet, 0.96, reasons);
  }

  if (jokeTemplateFamily && emojiBurst && (randomHandle || lowEntropy || decorativeTemplate)) {
    return buildLocalRuleHit(tweet, 0.93, reasons);
  }

  if (randomHandle && emojiDecoratedPhrase) {
    return buildLocalRuleHit(tweet, 0.95, reasons);
  }

  if (randomHandle && mathPrefix) {
    return buildLocalRuleHit(tweet, 0.93, reasons);
  }

  if (randomHandle && obscureScriptDeco) {
    return buildLocalRuleHit(tweet, 0.93, reasons);
  }

  if (randomHandle && decoratedCjkPattern) {
    return buildLocalRuleHit(tweet, 0.93, reasons);
  }

  if (randomHandle && decorativeTemplate) {
    return buildLocalRuleHit(tweet, 0.92, reasons);
  }

  // Standalone: emoji-decorated phrase is strong enough even without confirmed random handle
  if (emojiDecoratedPhrase && emojiBurst) {
    return buildLocalRuleHit(tweet, 0.88, reasons);
  }

  // Standalone: obscure-script-wrapped English phrase (e.g. Cham/Tai Viet/Javanese bots).
  // Fires even without randomHandle because the text pattern alone is highly distinctive.
  if (obscureScriptDeco) {
    return buildLocalRuleHit(tweet, 0.88, reasons);
  }

  // Standalone: decorative-symbol-wrapped short CJK phrase is also highly distinctive.
  if (decoratedCjkPattern) {
    return buildLocalRuleHit(tweet, 0.88, reasons);
  }

  if (defaultAvatar && (adultName || randomHandle || suspiciousPromoText || tinyToken || emojiOnly || lowInfoMixed)) {
    return buildLocalRuleHit(tweet, adultName || suspiciousPromoText ? 0.92 : 0.9, reasons);
  }

  if (emojiOnly) {
    return buildLocalRuleHit(tweet, 0.9, reasons);
  }

  if (singleLetterEmojiLure && (adultName || suspiciousPromoText || randomHandle)) {
    return buildLocalRuleHit(tweet, 0.9, reasons);
  }

  if (singleLetterEmojiLure && lowEntropy) {
    return buildLocalRuleHit(tweet, 0.9, reasons);
  }

  if (adultName && lowInfoText) {
    return buildLocalRuleHit(tweet, 0.95, reasons);
  }

  if (randomHandle && suspiciousPromoText && lowInfoText) {
    return buildLocalRuleHit(tweet, 0.89, reasons);
  }

  return null;
}

function splitObviousBotReplies(tweets, customKeywords = []) {
  const localResults = [];
  const modelTweets = [];
  const seen = new Set();

  (tweets || []).forEach(tweet => {
    const hit = detectObviousBotReply(tweet, customKeywords);
    if (hit?.handle) {
      const key = hit.handle.toLowerCase();
      if (!seen.has(key)) {
        seen.add(key);
        localResults.push(hit);
      }
      return;
    }
    modelTweets.push(tweet);
  });

  return { localResults, modelTweets };
}

// Simple Levenshtein-like similarity score for detecting near-duplicate messages
function calcTextSimilarity(text1, text2) {
  if (!text1 || !text2) return 0;
  const s1 = String(text1).trim().toLowerCase();
  const s2 = String(text2).trim().toLowerCase();
  if (s1 === s2) return 1;

  // 使用二元组（bigram）匹配：同时支持中文字符和拉丁单词
  // 中文：提取 CJK 字符序列的相邻字符对（bigram）
  // 拉丁：提取 3+ 字符的单词
  function tokenize(s) {
    const cjkChars = s.match(/[\u4e00-\u9fff\u3400-\u4dbf\uf900-\ufaff]/g) || [];
    const bigrams = [];
    for (let i = 0; i < cjkChars.length - 1; i++) {
      bigrams.push(cjkChars[i] + cjkChars[i + 1]);
    }
    const latin = s.match(/\w{3,}/g) || [];
    return [...bigrams, ...latin];
  }

  const tokens1 = tokenize(s1);
  const tokens2 = tokenize(s2);
  if (tokens1.length === 0 || tokens2.length === 0) return 0;

  const set2 = new Set(tokens2);
  const common = tokens1.filter(t => set2.has(t)).length;
  return common / Math.max(tokens1.length, tokens2.length);
}

function addCoordinatedLocalRuleResults(tweets, results, customKeywords = []) {
  if (!Array.isArray(tweets) || tweets.length < 2) return;

  const resultHandles = new Set(
    (results || [])
      .map(r => String(r?.handle || '').toLowerCase())
      .filter(Boolean)
  );
  const clustered = new Set();

  for (let i = 0; i < tweets.length; i++) {
    const a = tweets[i];
    const aText = String(a?.text || '').trim();
    const aCore = stripEmojiLikeChars(aText);
    if (aCore.length < 8 && !hasUrlLikeSignal(aText) && !hasSuspiciousPromoText(aText)) continue;

    const matches = [a];
    for (let j = i + 1; j < tweets.length; j++) {
      const b = tweets[j];
      if (String(a?.handle || '').toLowerCase() === String(b?.handle || '').toLowerCase()) continue;
      const bText = String(b?.text || '').trim();
      const sim = calcTextSimilarity(aText, bText);
      if (sim >= 0.9) {
        matches.push(b);
      }
    }

    const uniqueHandles = new Set(matches.map(t => String(t?.handle || '').toLowerCase()).filter(Boolean));
    if (uniqueHandles.size < 3) continue;

    const hasRiskContext = matches.some(t => {
      const text = String(t?.text || '');
      return hasUrlLikeSignal(text) ||
        hasSuspiciousPromoText(text) ||
        hasObviousBotKeyword(String(t?.displayName || ''), customKeywords) ||
        looksLikeRandomHandle(t?.handle);
    });
    if (!hasRiskContext) continue;

    matches.forEach(t => {
      const key = String(t?.handle || '').toLowerCase();
      if (!key || resultHandles.has(key) || clustered.has(key)) return;
      clustered.add(key);
      resultHandles.add(key);
      results.push(buildLocalRuleHit(t, 0.91, [
        `coordinated copy-paste replies across ${uniqueHandles.size} accounts`,
        'matched without AI'
      ]));
    });
  }
}

function addJokeTemplateClusterResults(tweets, results) {
  if (!Array.isArray(tweets) || tweets.length < 3) return;

  const resultHandles = new Set(
    (results || [])
      .map(r => String(r?.handle || '').toLowerCase())
      .filter(Boolean)
  );

  const families = new Map();
  (tweets || []).forEach(tweet => {
    const family = getEnglishJokeTemplateFamily(tweet?.text);
    if (!family) return;
    if (!looksLikeRandomHandle(tweet?.handle)) return;
    if (!hasEmojiBurst(tweet?.text, 4)) return;
    if (!families.has(family)) families.set(family, []);
    families.get(family).push(tweet);
  });

  families.forEach((items, family) => {
    const uniqueHandles = new Set(items.map(t => String(t?.handle || '').toLowerCase()).filter(Boolean));
    if (uniqueHandles.size < 3) return;

    items.forEach(tweet => {
      const key = String(tweet?.handle || '').toLowerCase();
      if (!key || resultHandles.has(key)) return;
      resultHandles.add(key);
      results.push(buildLocalRuleHit(tweet, 0.95, [
        `clustered english joke-template replies (${family}) across ${uniqueHandles.size} random handles`,
        'matched without AI'
      ]));
    });
  });

  // Emoji-decorated short English phrase cluster:
  // 3+ accounts with random handles posting short inspirational phrases wrapped in emoji/symbols.
  // Catches bots like @dqikco32633, @ansqyfgo458, @Hralx284483 etc. that per-tweet rules may miss
  // when the emoji count or symbol count is borderline.
  const phraseItems = [];
  (tweets || []).forEach(tweet => {
    const key = String(tweet?.handle || '').toLowerCase();
    if (!key || resultHandles.has(key)) return;
    if (!looksLikeRandomHandle(tweet?.handle)) return;
    const text = String(tweet?.text || '').trim();
    const words = text.match(/[a-zA-Z]{2,}/g) || [];
    if (words.length < 4 || words.length > 13) return;
    // The text must contain decoration beyond plain English (emoji, symbols, or non-ASCII).
    const englishLen = words.join('').length;
    const totalLen = text.replace(/\s/g, '').length;
    if (totalLen === 0 || englishLen / totalLen > 0.88) return;
    // Require at least some emoji or decorative signals
    if (countEmojiChars(text) < 3 && !hasDecorativeTemplateSignal(text) && !hasMathSymbolPrefix(text) && !hasObscureScriptDecoration(text)) return;
    phraseItems.push(tweet);
  });
  const phraseHandles = new Set(phraseItems.map(t => String(t?.handle || '').toLowerCase()).filter(Boolean));
  if (phraseHandles.size >= 3) {
    phraseItems.forEach(tweet => {
      const key = String(tweet?.handle || '').toLowerCase();
      if (!key || resultHandles.has(key)) return;
      resultHandles.add(key);
      results.push(buildLocalRuleHit(tweet, 0.93, [
        `emoji-decorated short English phrase bot cluster (${phraseHandles.size} accounts)`,
        'matched without AI'
      ]));
    });
  }
}

// Detect copy-paste/auto-reply patterns: accounts with near-identical messages
function detectAutoReplyBots(batch, results) {
  if (!batch || !results || batch.length < 2) return;

  // Build a handle→result map so we are not relying on array order.
  // The LLM response does not guarantee the same order as the input batch.
  const resultByHandle = new Map();
  results.forEach(r => {
    if (r?.handle) {
      resultByHandle.set(String(r.handle).toLowerCase(), r);
    }
  });

  // Group results by tweet similarity
  const tweetsWithResults = batch
    .map(tweet => ({
      tweet: tweet.text || '',
      handle: tweet.handle,
      result: resultByHandle.get(String(tweet.handle || '').toLowerCase())
    }))
    .filter(x => x.result);
  
  // Find clusters of similar tweets (90%+ similarity = likely copy-paste)
  for (let i = 0; i < tweetsWithResults.length; i++) {
    for (let j = i + 1; j < tweetsWithResults.length; j++) {
      const sim = calcTextSimilarity(tweetsWithResults[i].tweet, tweetsWithResults[j].tweet);
      if (sim > 0.85) {
        // High similarity detected! These are likely auto-reply bots
        // Boost confidence for both
        if (tweetsWithResults[i].result.confidence) {
          tweetsWithResults[i].result.confidence = Math.min(1, tweetsWithResults[i].result.confidence + 0.05);
        }
        if (tweetsWithResults[j].result.confidence) {
          tweetsWithResults[j].result.confidence = Math.min(1, tweetsWithResults[j].result.confidence + 0.05);
        }
        
        // Update reason to mention copy-paste detection
        const similarity = Math.round(sim * 100);
        if (tweetsWithResults[i].result.reason) {
          tweetsWithResults[i].result.reason += ` | 复制粘贴(${similarity}%相似度)`;
        }
        if (tweetsWithResults[j].result.reason) {
          tweetsWithResults[j].result.reason += ` | 复制粘贴(${similarity}%相似度)`;
        }
        tweetsWithResults[i].result.isSpamOrBot = true;
        tweetsWithResults[j].result.isSpamOrBot = true;
      }
    }
  }
}

function normalizeCandidates(results, threshold = CONFIDENCE_THRESHOLD) {
  const minConfidence = normalizeThreshold(threshold);
  console.log(`[Normalize] 收到结果总数: ${results.length}, 置信度门槛: ${minConfidence}`);
  
  // Log all results before filtering
  results.forEach((r, idx) => {
    const reason = r.isSpamOrBot ? '✓ 是机器人' : '✗ 不是机器人';
    const passThreshold = r.confidence >= minConfidence ? '✓' : '✗';
    console.log(`  [${idx}] ${r.handle} (${r.displayName}) 置信度: ${(r.confidence || 0).toFixed(2)} ${passThreshold} ${reason}`);
  });
  
  const filtered = results.filter(r => r.isSpamOrBot && r.confidence >= minConfidence);
  console.log(`[Normalize] 过滤后通过门槛的: ${filtered.length}`);
  
  const byHandle = {};

  filtered.forEach(r => {
    if (!r || !r.handle) return;
    const key = String(r.handle).toLowerCase();
    if (!byHandle[key] || Number(r.confidence || 0) > Number(byHandle[key].confidence || 0)) {
      byHandle[key] = {
        handle: r.handle,
        displayName: r.displayName || '',
        confidence: Number(r.confidence || 0),
        reason: r.reason || '',
        evidenceTweet: r.evidenceTweet || '',
        selected: Number(r.confidence || 0) >= 0.9
      };
    }
  });

  return Object.values(byHandle).sort((a, b) => b.confidence - a.confidence);
}

/**
 * 合并两批候选结果：对同一 handle 取置信度最高的那条，最终按置信度倒序排列。
 * 用于多次点击分析时累积所有发现的 bot，而不是每次覆盖。
 */
function mergeCandidateLists(existing, newOnes) {
  const byHandle = {};
  [...existing, ...newOnes].forEach(c => {
    if (!c || !c.handle) return;
    const key = String(c.handle).toLowerCase();
    if (!byHandle[key] || Number(c.confidence || 0) > Number(byHandle[key].confidence || 0)) {
      byHandle[key] = c;
    }
  });
  return Object.values(byHandle).sort((a, b) => b.confidence - a.confidence);
}

function sendToTab(tabId, msg) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, msg, resp => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(resp);
      }
    });
  });
}

function ensureContentScript(tabId) {
  return new Promise((resolve, reject) => {
    chrome.scripting.executeScript(
      { target: { tabId }, files: ['content/content.js'] },
      () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve();
        }
      }
    );
  });
}

async function sendToTabSafe(tabId, msg) {
  try {
    return await sendToTab(tabId, msg);
  } catch (e) {
    const missingReceiver = String(e.message || '').includes('Receiving end does not exist');
    if (!missingReceiver) throw e;
    await ensureContentScript(tabId);
    return sendToTab(tabId, msg);
  }
}

async function setAnalysisState(tabId, state) {
  const key = analysisKey(tabId);
  await storageSet({
    [key]: {
      ...state,
      tabId,
      updatedAt: Date.now()
    }
  });
}

async function getAnalysisState(tabId) {
  const key = analysisKey(tabId);
  const data = await storageGet([key]);
  return data[key] || null;
}

async function startAnalysisForTab(tabId, overrides = {}) {
  if (runningTabs.has(tabId)) return;
  runningTabs.add(tabId);

  try {
    let analysisSourceUrl = '';
    // 获取 tab URL，初始化缓存
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    if (tab?.url) {
      analysisSourceUrl = String(tab.url);
      initPageAnalysisCache(tabId, tab.url);
    }

    await setAnalysisState(tabId, {
      status: 'running',
      scannedTweetCount: 0,
      candidates: [],
      error: '',
      progressText: '正在采集推文…',
      sourceUrl: analysisSourceUrl,
      autoQueued: false
    });

    const cfg = await getProviderConfig();
    if (typeof overrides.aiAnalysisEnabled === 'boolean') {
      cfg.aiAnalysisEnabled = overrides.aiAnalysisEnabled;
    }
    const targetRounds = Math.ceil(cfg.scrapeMaxTweets / 6);
    const effectiveScrapeRounds = Math.min(300, Math.max(cfg.scrapeMaxRounds, targetRounds));
    const scrapeTimeoutMs = Math.min(
      600000,
      Math.max(15000, cfg.scrapeScrollWaitMs * effectiveScrapeRounds + 15000)
    );

    const scrapeResp = await withTimeout(
      sendToTabSafe(tabId, {
        action: 'scrapeTweets',
        scrapeConfig: {
          scrollWaitMs: cfg.scrapeScrollWaitMs,
          maxRounds: effectiveScrapeRounds,
          maxTweets: cfg.scrapeMaxTweets,
          stagnantRounds: cfg.scrapeStagnantRounds
        }
      }),
      scrapeTimeoutMs,
      '采集超时，请刷新页面后重试'
    );
    if (!scrapeResp?.ok) {
      throw new Error(scrapeResp?.error || '采集失败');
    }

    const allTweets = scrapeResp.tweets || [];
    if (allTweets.length === 0) {
      await setAnalysisState(tabId, {
        status: 'empty',
        scannedTweetCount: 0,
        candidates: [],
        error: '',
        progressText: '',
        sourceUrl: analysisSourceUrl,
        autoQueued: false
      });
      return;
    }

    const aiAvailable = canUseAiProvider(cfg);

    // For AI analysis: skip already-analyzed users to avoid expensive re-calls.
    // For local-only analysis: always re-run local rules on ALL tweets so that
    // bots missed in a previous run (before rule improvements) are still caught.
    const tweets = aiAvailable ? filterNewUsers(tabId, allTweets) : allTweets;
    const skippedCount = aiAvailable ? (allTweets.length - tweets.length) : 0;

    if (tweets.length === 0) {
      // All users already analyzed — only reachable in AI mode.
      await setAnalysisState(tabId, {
        status: 'empty',
        scannedTweetCount: allTweets.length,
        candidates: [],
        error: '',
        progressText: skippedCount > 0 ? `已采集 ${allTweets.length} 条，全部为已分析用户（跳过 ${skippedCount} 个）` : '',
        sourceUrl: analysisSourceUrl,
        autoQueued: false
      });
      return;
    }
    await setAnalysisState(tabId, {
      status: 'running',
      scannedTweetCount: allTweets.length,
      candidates: [],
      error: '',
      progressText: aiAvailable
        ? `已采集 ${allTweets.length} 条，正在分析 ${tweets.length} 个新用户${skippedCount > 0 ? `（跳过 ${skippedCount} 个已分析用户）` : ''}…`
        : `已采集 ${allTweets.length} 条，正在本地规则扫描 ${tweets.length} 个用户${skippedCount > 0 ? `（跳过 ${skippedCount} 个已分析用户）` : ''}…`,
      sourceUrl: analysisSourceUrl,
      autoQueued: false
    });
    // Yield to the event loop so the popup's 900 ms poll can see the progress message
    // before synchronous local-rule processing blocks the thread.
    await sleep(0);

    const prefilter = splitObviousBotReplies(tweets, cfg.obviousBotKeywords);
    const results = prefilter.localResults.slice();

    addCoordinatedLocalRuleResults(tweets, results, cfg.obviousBotKeywords);
    addJokeTemplateClusterResults(tweets, results);

    let aiOnlyDetections = [];
    if (prefilter.modelTweets.length > 0 && aiAvailable) {
      const modelResults = await analyzeTweetsOptimized(prefilter.modelTweets, cfg, async (done, total) => {
        await setAnalysisState(tabId, {
          status: 'running',
          scannedTweetCount: allTweets.length,
          candidates: [],
          error: '',
          progressText: `已采集 ${allTweets.length} 条；AI 分析 ${done}/${total}；本地预过滤 ${prefilter.localResults.length} 个`,
          sourceUrl: analysisSourceUrl,
          autoQueued: false
        });
      });
      results.push(...modelResults);

      // Detect coordinated copy-paste/auto-reply bots among tweets that still need model analysis.
      detectAutoReplyBots(prefilter.modelTweets, modelResults);

      // Collect AI-only detections: items AI flagged as bots that local rules missed.
      // These are useful for enriching local rules in the future.
      const threshold = normalizeThreshold(cfg.spamConfidenceThreshold);
      aiOnlyDetections = modelResults
        .filter(r => r.isSpamOrBot && Number(r.confidence || 0) >= threshold)
        .map(r => ({
          handle: String(r.handle || ''),
          displayName: String(r.displayName || ''),
          confidence: Number(r.confidence || 0),
          reason: String(r.reason || ''),
          evidenceTweet: String(r.evidenceTweet || '')
        }));
    }

    if (!aiAvailable) {
      // Always show local-only completion status so the popup displays a meaningful
      // progress message while normalizeCandidates / storage merging runs.
      await setAnalysisState(tabId, {
        status: 'running',
        scannedTweetCount: allTweets.length,
        candidates: [],
        error: '',
        progressText: `已采集 ${allTweets.length} 条；本地规则完成，发现 ${results.length} 个疑似账号`,
        sourceUrl: analysisSourceUrl,
        autoQueued: false
      });
      await sleep(0);
    }

    const newCandidates = normalizeCandidates(results, cfg.spamConfidenceThreshold);

    // Only cache analyzed handles for AI mode to avoid re-sending the same users
    // to the (expensive) AI model.  Local-only mode always re-analyzes all tweets
    // so that bots missed by older rules are caught after a rule update.
    if (aiAvailable) {
      const analyzedHandles = tweets.map(t => t.handle);
      addScannedUserHandles(tabId, analyzedHandles);
    }

    // 与上次分析结果合并，避免多次点击只保留最新一批结果
    const prevState = await getAnalysisState(tabId);
    const prevCandidates =
      prevState?.sourceUrl === analysisSourceUrl && Array.isArray(prevState?.candidates)
        ? prevState.candidates
        : [];
    const merged = mergeCandidateLists(prevCandidates, newCandidates);

    let autoQueued = false;
    if (merged.length > 0) {
      const settings = await storageGet(['autoBlock']).catch(() => ({}));
      if (Boolean(settings.autoBlock)) {
        const added = enqueueBlockAccounts(merged, {
          scannedCount: allTweets.length,
          candidateCount: merged.length,
          sourceUrl: analysisSourceUrl
        });
        if (added > 0) {
          autoQueued = true;
          runGlobalBlockQueue();
        }
      }
    }

    await setAnalysisState(tabId, {
      status: merged.length > 0 ? 'done' : 'empty',
      scannedTweetCount: allTweets.length,
      candidates: merged,
      error: '',
      progressText: '',
      sourceUrl: analysisSourceUrl,
      autoQueued,
      aiOnlyDetections: aiOnlyDetections.length > 0 ? aiOnlyDetections : []
    });
  } catch (e) {
    const prev = (await getAnalysisState(tabId)) || { scannedTweetCount: 0 };
    await setAnalysisState(tabId, {
      status: 'error',
      scannedTweetCount: prev.scannedTweetCount || 0,
      candidates: [],
      error: e.message || '分析失败',
      progressText: '',
      sourceUrl: prev.sourceUrl || '',
      autoQueued: false
    });
  } finally {
    runningTabs.delete(tabId);
  }
}

// ── Message handler ───────────────────────────────────────────────────────────

function getDeepScanStatusSnapshot() {
  return {
    running: deepScanState.running,
    paused: deepScanState.paused,
    handle: deepScanState.handle,
    postsCount: deepScanState.postsCount,
    repliesCount: deepScanState.repliesCount,
    candidatesCount: deepScanState.candidatesCount,
    currentStep: deepScanState.currentStep,
    completed: deepScanState.completed,
    candidates: deepScanState.candidates,
    error: deepScanState.error
  };
}

async function startDeepScan(config) {
  deepScanState.running = true;
  deepScanState.paused = false;
  deepScanState.cancelled = false;
  deepScanState.handle = config.handle || '';
  deepScanState.config = config;
  deepScanState.postsCount = 0;
  deepScanState.repliesCount = 0;
  deepScanState.repliesCollected = [];
  deepScanState.candidates = [];
  deepScanState.candidatesCount = 0;
  deepScanState.completed = false;
  deepScanState.currentStep = '正在初始化…';
  deepScanState.scannedPostUrls = new Set();
  deepScanState.error = '';

  try {
    const cfg = await getProviderConfig();
    if (typeof deepScanState.config.aiAnalysisEnabled === 'boolean') {
      cfg.aiAnalysisEnabled = deepScanState.config.aiAnalysisEnabled;
    }
    await performDeepScan(cfg);
  } catch (e) {
    deepScanState.error = e.message;
    deepScanState.running = false;
  }
}

async function performDeepScan(cfg) {
  const handle = deepScanState.handle.replace('@', '');
  const maxPosts = deepScanState.config.maxPosts || 20;
  const maxRepliesPerPost = deepScanState.config.maxRepliesPerPost || 100;
  const maxTotalReplies = deepScanState.config.maxTotalReplies || 1000;

  console.log(`[DeepScan] 开始扫描 @${handle}, 配置: maxPosts=${maxPosts}, maxRepliesPerPost=${maxRepliesPerPost}, maxTotalReplies=${maxTotalReplies}`);

  try {
    deepScanState.currentStep = `正在打开 @${handle} 的主页…`;
    const profileUrl = `https://x.com/${handle}`;
    let workerTab = deepScanState.workerTabId ? await chrome.tabs.get(deepScanState.workerTabId).catch(() => null) : null;

    if (!workerTab) {
      workerTab = await tabsCreate(profileUrl, true);
      deepScanState.workerTabId = workerTab.id;
    } else {
      await tabsUpdate(workerTab.id, { url: profileUrl, active: true });
    }

    try {
      await waitForTabLoaded(workerTab.id, 15000);
    } catch (_) {}

    deepScanState.currentStep = '正在采集最近的帖子链接…';
    const postUrls = await collectUserPostLinks(workerTab.id, maxPosts, handle, cfg);
    console.log(`[DeepScan] 采集到 ${postUrls.length} 条帖子链接`);

    if (deepScanState.cancelled) {
      deepScanState.running = false;
      return;
    }

    deepScanState.postsCount = postUrls.length;
    deepScanState.currentStep = `已采集 ${postUrls.length} 条帖子，正在采集回复…`;

    // Process each post
    for (let i = 0; i < postUrls.length; i++) {
      if (deepScanState.cancelled) {
        deepScanState.running = false;
        return;
      }

      while (deepScanState.paused) {
        await sleep(500);
        if (deepScanState.cancelled) {
          deepScanState.running = false;
          return;
        }
      }

      const postUrl = postUrls[i];
      if (deepScanState.scannedPostUrls.has(postUrl)) continue;
      deepScanState.scannedPostUrls.add(postUrl);

      deepScanState.currentStep = `采集第 ${i + 1}/${postUrls.length} 条帖子的回复…`;
      await tabsUpdate(workerTab.id, { url: postUrl, active: true });

      try {
        await waitForTabLoaded(workerTab.id, 12000);
      } catch (_) {}

      const replies = await collectPostReplies(workerTab.id, maxRepliesPerPost, cfg);
      console.log(`[DeepScan] 第 ${i + 1} 条帖子采集到 ${replies.length} 条回复`);
      deepScanState.repliesCollected.push(...replies);
      deepScanState.repliesCount = deepScanState.repliesCollected.length;
      console.log(`[DeepScan] 累计回复数: ${deepScanState.repliesCount}`);

      if (deepScanState.repliesCount >= maxTotalReplies) {
        deepScanState.repliesCollected = deepScanState.repliesCollected.slice(0, maxTotalReplies);
        deepScanState.repliesCount = maxTotalReplies;
        console.log(`[DeepScan] 已达到总回复限制 ${maxTotalReplies}`);
        break;
      }

      await sleep(1500);
    }

    if (deepScanState.repliesCollected.length === 0) {
      console.log(`[DeepScan] 未找到任何回复`);
      deepScanState.running = false;
      deepScanState.currentStep = '未找到任何回复';
      deepScanState.completed = true;
      return;
    }

    // Filter out the OP (original poster)
    const opHandle = handle.toLowerCase();
    const filteredReplies = deepScanState.repliesCollected.filter(
      r => (r.handle || '').replace('@', '').toLowerCase() !== opHandle
    );
    console.log(`[DeepScan] 原始回复数: ${deepScanState.repliesCollected.length}, 排除OP后: ${filteredReplies.length}`);

    deepScanState.currentStep = `正在分析 ${filteredReplies.length} 条回复…`;
    const prefilter = splitObviousBotReplies(filteredReplies, cfg.obviousBotKeywords);
    console.log(`[DeepScan] 本地预过滤 - 明显机器人: ${prefilter.localResults.length}, 需要模型分析: ${prefilter.modelTweets.length}`);
    
    let results = [...prefilter.localResults];
    const aiAvailable = canUseAiProvider(cfg);
    addCoordinatedLocalRuleResults(filteredReplies, results, cfg.obviousBotKeywords);
    addJokeTemplateClusterResults(filteredReplies, results);

    if (prefilter.modelTweets.length > 0 && aiAvailable) {
      const modelResults = await analyzeTweetsOptimized(prefilter.modelTweets, cfg);
      console.log(`[DeepScan] 模型分析 - 返回结果数: ${modelResults.length}`);
      results.push(...modelResults);
      detectAutoReplyBots(prefilter.modelTweets, modelResults);
      console.log(`[DeepScan] 自动回复检测后 - 总结果数: ${results.length}`);
    } else if (prefilter.modelTweets.length > 0) {
      deepScanState.currentStep = `AI 未启用，已用本地规则分析 ${filteredReplies.length} 条回复`;
      console.log(`[DeepScan] AI 未启用，跳过 ${prefilter.modelTweets.length} 条模型分析候选`);
    }

    deepScanState.candidates = normalizeCandidates(results, cfg.spamConfidenceThreshold);
    deepScanState.candidatesCount = deepScanState.candidates.length;
    console.log(`[DeepScan] 标准化候选人 (门槛: ${cfg.spamConfidenceThreshold}) - 最终: ${deepScanState.candidatesCount}`);
    deepScanState.candidates.forEach(c => {
      console.log(`  - ${c.handle} (${c.displayName}) 置信度: ${c.confidence.toFixed(2)}`);
    });
    deepScanState.currentStep = `扫描完成，找到 ${deepScanState.candidatesCount} 个疑似账号`;
    deepScanState.completed = true;

    deepScanState.running = false;
    saveDeepScanState();
  } catch (e) {
    deepScanState.error = e.message;
    deepScanState.running = false;
    saveDeepScanState();
  } finally {
    // Clean up worker tab
    if (deepScanState.workerTabId) {
      try {
        await tabsRemove(deepScanState.workerTabId);
      } catch (_) {}
      deepScanState.workerTabId = null;
    }
  }
}

function continueDeepScan() {
  // Resume deep scan if paused
  if (deepScanState.paused && deepScanState.running) {
    deepScanState.paused = false;
  }
}

async function collectUserPostLinks(tabId, maxLinks = 20, targetHandle = '', cfg = {}) {
  const links = [];
  const linkSet = new Set();
  const maxRounds = normalizeScrapeMaxRounds(cfg.scrapeMaxRounds);
  const waitMs = normalizeScrapeScrollWaitMs(cfg.scrapeScrollWaitMs);
  const stagnantLimit = normalizeScrapeStagnantRounds(cfg.scrapeStagnantRounds);
  let lastCount = 0;
  let stagnantRounds = 0;
  // Normalise handle for path matching: "@foo" or "foo" → "/foo/"
  const handleSlug = targetHandle.replace(/^@/, '').toLowerCase();

  await scrollTabToTop(tabId, waitMs);

  for (let i = 0; i < maxRounds; i++) {
    const result = await executeInTab(tabId, (slug) => {
      const posts = [];
      const articles = document.querySelectorAll('article[data-testid="tweet"]');
      articles.forEach(article => {
        try {
          const timeEl = article.querySelector('time');
          const statusA = timeEl ? timeEl.closest('a') : null;
          const statusPath = statusA ? statusA.getAttribute('href') || '' : '';
          // Bug 3 fix: only collect posts that belong to the target blogger.
          // A post URL follows the pattern "/{handle}/status/{id}", so we
          // verify the path starts with the expected user segment.
          if (!statusPath) return;
          const pathLower = statusPath.toLowerCase();
          const expectedPrefix = `/${slug}/status/`;
          if (!pathLower.startsWith(expectedPrefix)) return;
          const url = `https://x.com${statusPath}`;
          if (!posts.includes(url)) posts.push(url);
        } catch (_) {}
      });
      return posts;
    }, [handleSlug]).catch(() => []);

    result.forEach(link => {
      if (!linkSet.has(link)) {
        linkSet.add(link);
        links.push(link);
      }
    });

    if (links.length >= maxLinks) break;

    if (links.length <= lastCount) {
      stagnantRounds++;
      if (stagnantRounds >= stagnantLimit) break;
    } else {
      stagnantRounds = 0;
    }

    lastCount = links.length;
    await executeInTab(tabId, () => {
      function isScrollableElement(el) {
        if (!el || el === document.body) return false;
        const style = window.getComputedStyle(el);
        if (!style) return false;
        const overflowY = style.overflowY || '';
        const canScroll = overflowY === 'auto' || overflowY === 'scroll' || overflowY === 'overlay';
        return canScroll && (el.scrollHeight - el.clientHeight) > 80;
      }

      function getPreferredScrollRoot() {
        const tweetArticle = document.querySelector('article[data-testid="tweet"]');
        let node = tweetArticle;
        while (node && node !== document.body) {
          if (isScrollableElement(node)) return node;
          node = node.parentElement;
        }

        const primaryColumn = document.querySelector('[data-testid="primaryColumn"]');
        node = primaryColumn;
        while (node && node !== document.body) {
          if (isScrollableElement(node)) return node;
          node = node.parentElement;
        }

        return document.scrollingElement || document.documentElement || document.body;
      }

      const root = getPreferredScrollRoot();
      if (!root || root === document.documentElement || root === document.body || root === document.scrollingElement) {
        window.scrollBy({ top: Math.max(window.innerHeight * 0.9, 800), behavior: 'auto' });
      } else {
        root.scrollBy({ top: Math.max(window.innerHeight * 0.9, 800), behavior: 'auto' });
      }
      return true;
    }).catch(() => {});
    const waitNextMs = stagnantRounds > 0 ? waitMs : Math.max(600, Math.round(waitMs * 0.82));
    await sleep(waitNextMs);
  }

  return links.slice(0, maxLinks);
}

/**
 * Poll until at least `minCount` article[data-testid="tweet"] elements exist
 * in the tab's DOM, or until `timeoutMs` elapses.
 * Returns true if the target count was reached, false on timeout.
 */
async function waitForRepliesRendered(tabId, minCount = 2, timeoutMs = 15000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const count = await executeInTab(tabId, () =>
      document.querySelectorAll('article[data-testid="tweet"]').length
    ).catch(() => 0);
    if (count >= minCount) return true;
    await sleep(300);
  }
  return false;
}

async function scrollTabToTop(tabId, waitMs = 800) {
  const settleMs = Math.max(250, Math.min(1200, Math.round(waitMs * 0.75)));
  let stableRounds = 0;
  let lastY = -1;

  for (let i = 0; i < 8; i++) {
    const currentY = await executeInTab(tabId, (delayMs) => {
      function isScrollableElement(el) {
        if (!el || el === document.body) return false;
        const style = window.getComputedStyle(el);
        if (!style) return false;
        const overflowY = style.overflowY || '';
        const canScroll = overflowY === 'auto' || overflowY === 'scroll' || overflowY === 'overlay';
        return canScroll && (el.scrollHeight - el.clientHeight) > 80;
      }

      function getPreferredScrollRoot() {
        const tweetArticle = document.querySelector('article[data-testid="tweet"]');
        let node = tweetArticle;
        while (node && node !== document.body) {
          if (isScrollableElement(node)) return node;
          node = node.parentElement;
        }

        const primaryColumn = document.querySelector('[data-testid="primaryColumn"]');
        node = primaryColumn;
        while (node && node !== document.body) {
          if (isScrollableElement(node)) return node;
          node = node.parentElement;
        }

        return document.scrollingElement || document.documentElement || document.body;
      }

      function getScrollTop(root) {
        if (!root || root === document.documentElement || root === document.body || root === document.scrollingElement) {
          return Math.max(
            window.scrollY || 0,
            document.documentElement?.scrollTop || 0,
            document.body?.scrollTop || 0
          );
        }
        return root.scrollTop || 0;
      }

      return new Promise(resolve => {
        const root = getPreferredScrollRoot();
        if (!root || root === document.documentElement || root === document.body || root === document.scrollingElement) {
          window.scrollTo({ top: 0, behavior: 'auto' });
        } else {
          root.scrollTo({ top: 0, behavior: 'auto' });
        }
        setTimeout(() => {
          resolve(getScrollTop(root));
        }, delayMs);
      });
    }, [settleMs]).catch(() => null);

    if (currentY === null) return;
    if (currentY <= 2) {
      stableRounds += 1;
      if (stableRounds >= 2) break;
    } else if (currentY === lastY) {
      break;
    }
    lastY = currentY;
  }
}

async function collectPostReplies(tabId, maxReplies = 100, cfg = {}) {
  const waitMs = normalizeScrapeScrollWaitMs(cfg.scrapeScrollWaitMs);
  const maxRounds = normalizeScrapeMaxRounds(cfg.scrapeMaxRounds);
  const stagnantRounds = normalizeScrapeStagnantRounds(cfg.scrapeStagnantRounds);
  const targetBasedRounds = Math.ceil(maxReplies / 6);
  const effectiveRounds = Math.min(300, Math.max(maxRounds, targetBasedRounds));
  const scrapeTimeoutMs = Math.min(
    600000,
    Math.max(20000, waitMs * effectiveRounds + 20000)
  );

  const repliesAppearTimeout = Math.max(15000, Math.round(waitMs * 8));
  const repliesAppeared = await waitForRepliesRendered(tabId, 2, repliesAppearTimeout);
  if (!repliesAppeared) {
    console.log('[DeepScan] collectPostReplies: 等待回复节点超时，跳过此帖');
    return [];
  }

  const scrapeResp = await withTimeout(
    sendToTabSafe(tabId, {
      action: 'scrapeTweets',
      scrapeConfig: {
        initialWaitMs: repliesAppearTimeout,
        scrollWaitMs: waitMs,
        maxRounds: effectiveRounds,
        maxTweets: maxReplies + 6,
        stagnantRounds
      }
    }),
    scrapeTimeoutMs,
    '深度扫描采集回复超时，请稍后重试'
  );

  if (!scrapeResp?.ok) {
    throw new Error(scrapeResp?.error || '深度扫描采集回复失败');
  }

  return (scrapeResp.tweets || []).slice(0, maxReplies).map(tweet => ({
    ...tweet,
    text: String(tweet?.text || '').trim() || '[媒体内容/无文字推文]'
  }));
}

// ── Tab 事件监听：页面分析缓存管理 ────────────────────────────────────────────
/**
 * 监听 tab URL 变化，清空旧缓存
 */
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete' || !tab.url) return;

  if (pageAnalysisCache[tabId]) {
    const oldUrl = pageAnalysisCache[tabId].currentUrl;
    if (oldUrl !== tab.url) {
      console.log(`[Cache] Tab ${tabId} URL 变化，清空旧缓存`);
      clearPageAnalysisCache(tabId);
      initPageAnalysisCache(tabId, tab.url);
    }
  }

  // URL changed: clear stale analysis state so old-page results are never
  // auto-applied on a new page in the same tab.
  getAnalysisState(tabId)
    .then(state => {
      if (!state) return;
      const stateUrl = String(state.sourceUrl || '');
      if (!stateUrl || stateUrl === tab.url) return;
      runningTabs.delete(tabId);
      storageRemove([analysisKey(tabId)]).catch(() => {});
    })
    .catch(() => {});
});
/**
 * 监听 tab 关闭，清空缓存并释放并发槽
 */
chrome.tabs.onRemoved.addListener(tabId => {
  clearPageAnalysisCache(tabId);
  runningTabs.delete(tabId);
});

// ── Message handler ───────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.action === 'backgroundUiBlock') {
    blockViaHiddenTab(msg.handle)
      .then(() => sendResponse({ ok: true }))
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }

  if (msg.action === 'enqueueGlobalBlockAccounts') {
    const added = enqueueBlockAccounts(msg.accounts || [], msg.meta || {});
    runGlobalBlockQueue();
    sendResponse({ ok: true, added, status: getBlockStatusSnapshot() });
    return false;
  }

  if (msg.action === 'enqueueGlobalBlockText') {
    const accounts = parseHandlesFromText(msg.text || '');
    const added = enqueueBlockAccounts(accounts);
    runGlobalBlockQueue();
    sendResponse({ ok: true, added, status: getBlockStatusSnapshot() });
    return false;
  }

  if (msg.action === 'getGlobalBlockStatus') {
    sendResponse({ ok: true, status: getBlockStatusSnapshot() });
    return false;
  }

  if (msg.action === 'retryFailedGlobalBlocking') {
    const retried = retryFailedBlockItems(); // recalcTotals → saveBlockQueueState inside
    if (retried > 0) {
      runGlobalBlockQueue();
    }
    sendResponse({ ok: true, retried, status: getBlockStatusSnapshot() });
    return false;
  }

  if (msg.action === 'clearDoneGlobalBlocking') {
    const cleared = clearCompletedBlockItems(); // recalcTotals → saveBlockQueueState inside
    sendResponse({ ok: true, cleared, status: getBlockStatusSnapshot() });
    return false;
  }

  if (msg.action === 'clearDeepScanCompleted') {
    deepScanState.completed       = false;
    deepScanState.candidates      = [];
    deepScanState.candidatesCount = 0;
    deepScanState.error           = '';
    deepScanState.currentStep     = '';
    saveDeepScanState();
    sendResponse({ ok: true });
    return false;
  }

  if (msg.action === 'pauseGlobalBlocking') {
    blockQueue.paused   = true;
    saveBlockQueueState();
    sendResponse({ ok: true, status: getBlockStatusSnapshot() });
    return false;
  }

  if (msg.action === 'resumeGlobalBlocking') {
    blockQueue.paused   = false;
    blockQueue.errorMsg = '';
    blockQueue.consecutiveFails = 0;
    saveBlockQueueState();
    runGlobalBlockQueue();
    sendResponse({ ok: true, status: getBlockStatusSnapshot() });
    return false;
  }

  if (msg.action === 'startAnalysisForTab') {
    if (runningTabs.has(msg.tabId)) {
      getAnalysisState(msg.tabId)
        .then(state => sendResponse({
          ok: true,
          alreadyRunning: true,
          state: state || {
            status: 'running',
            scannedTweetCount: 0,
            candidates: [],
            error: '',
            progressText: '分析任务仍在运行…'
          }
        }))
        .catch(e => sendResponse({ ok: false, error: e.message }));
      return true;
    }

    if (runningTabs.size >= MAX_CONCURRENT_ANALYSES) {
      sendResponse({
        ok: false,
        error: `已有 ${runningTabs.size} 个分析任务并行运行，最多支持 ${MAX_CONCURRENT_ANALYSES} 个。请等待完成后再试。`
      });
      return false;
    }

    getProviderConfig()
      .then(cfg => {
        if (typeof msg.aiAnalysisEnabled === 'boolean') {
          cfg.aiAnalysisEnabled = msg.aiAnalysisEnabled;
        }
        startAnalysisForTab(msg.tabId, { aiAnalysisEnabled: cfg.aiAnalysisEnabled });
        sendResponse({
          ok: true,
          started: true,
          localOnly: !canUseAiProvider(cfg),
          aiAnalysisEnabled: cfg.aiAnalysisEnabled
        });
      })
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }

  if (msg.action === 'getProviderConfigStatus') {
    getProviderConfig()
      .then(cfg => {
        const issue = getProviderConfigIssue(cfg);
        sendResponse({
          ok: true,
          configured: !issue,
          aiAnalysisEnabled: cfg.aiAnalysisEnabled,
          aiReady: canUseAiProvider(cfg),
          localRulesAvailable: true,
          issue
        });
      })
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }

  if (msg.action === 'testProviderConfig') {
    testProviderConfig()
      .then(result => sendResponse({ ok: true, result }))
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }

  if (msg.action === 'getAnalysisForTab') {
    const tid = msg.tabId;
    getAnalysisState(tid)
      .then(async state => {
        // If storage says running but SW was restarted (runningTabs empty),
        // the analysis is a zombie — mark it as interrupted so popup unblocks.
        if (state && state.status === 'running' && !runningTabs.has(tid)) {
          state = { ...state, status: 'error', error: '分析任务已中断（扩展重启）', progressText: '' };
          await setAnalysisState(tid, state).catch(() => {});
        }
        sendResponse({ ok: true, state });
      })
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }

  if (msg.action === 'clearAnalysisForTab') {
    if (runningTabs.has(msg.tabId)) {
      sendResponse({ ok: false, error: '分析任务仍在运行，暂不能清理状态。' });
      return false;
    }

    // 清空分析缓存和页面分析缓存
    clearPageAnalysisCache(msg.tabId);
    
    storageRemove([analysisKey(msg.tabId)])
      .then(() => sendResponse({ ok: true }))
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }

  // Backward compatibility with older popup flow.
  if (msg.action === 'analyzeTweets') {
    getProviderConfig()
      .then(async cfg => {
        const tweets = msg.tweets || [];
        const prefilter = splitObviousBotReplies(tweets, cfg.obviousBotKeywords);
        const results = prefilter.localResults.slice();
        addCoordinatedLocalRuleResults(tweets, results, cfg.obviousBotKeywords);
        const modelResults = prefilter.modelTweets.length > 0 && canUseAiProvider(cfg)
          ? await analyzeTweetsOptimized(prefilter.modelTweets, cfg)
          : [];
        if (modelResults.length > 0) {
          detectAutoReplyBots(prefilter.modelTweets, modelResults);
        }
        return normalizeCandidates(results.concat(modelResults), cfg.spamConfidenceThreshold);
      })
      .then(results => sendResponse({ ok: true, results }))
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }

  // Deep Scan
  if (msg.action === 'startDeepScan') {
    if (deepScanState.running) {
      sendResponse({ ok: false, error: '深度扫描已在运行中' });
      return false;
    }
    startDeepScan(msg.config);
    sendResponse({ ok: true });
    return false;
  }

  if (msg.action === 'getDeepScanStatus') {
    sendResponse({ ok: true, status: getDeepScanStatusSnapshot() });
    return false;
  }

  if (msg.action === 'pauseDeepScan') {
    deepScanState.paused = true;
    sendResponse({ ok: true });
    return false;
  }

  if (msg.action === 'resumeDeepScan') {
    deepScanState.paused = false;
    if (!deepScanState.running) {
      // Resume the deep scan task
      continueDeepScan();
    }
    sendResponse({ ok: true });
    return false;
  }

  if (msg.action === 'cancelDeepScan') {
    deepScanState.cancelled = true;
    deepScanState.running = false;
    sendResponse({ ok: true });
    return false;
  }
});
